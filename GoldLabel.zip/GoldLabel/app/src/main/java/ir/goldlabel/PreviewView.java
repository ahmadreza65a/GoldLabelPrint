package ir.goldlabel;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.DashPathEffect;
import android.graphics.Paint;
import android.view.MotionEvent;
import android.view.View;

/** Live preview. Tap to switch between whole page and zoomed label. */
public class PreviewView extends View {
    private LabelSettings st;
    private String a = "", b = "", qr = null, bar = null;
    private boolean zoomLabel = true;

    public PreviewView(Context ctx) {
        super(ctx);
        setClickable(true);
    }

    public void setData(LabelSettings st, String a, String b, String qr, String bar) {
        this.qr = qr;
        this.bar = bar;
        this.st = st;
        this.a = a;
        this.b = b;
        invalidate();
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        if (e.getAction() == MotionEvent.ACTION_UP) {
            zoomLabel = !zoomLabel;
            invalidate();
            performClick();
        }
        return true;
    }

    @Override
    public boolean performClick() {
        return super.performClick();
    }

    @Override
    protected void onDraw(Canvas c) {
        c.drawColor(0xFFF4EFE3);
        if (st == null) return;
        float pageW = LabelRenderer.pageWidth(st);
        float H = st.labelHeight;
        float lx = LabelRenderer.labelX(st);
        float vx0, vW;
        if (zoomLabel) { vx0 = lx - 2f; vW = st.labelWidth + 4f; }
        else { vx0 = -1f; vW = pageW + 2f; }
        float vH = H + 4f;
        float s = Math.min(getWidth() / vW, getHeight() / vH);
        if (s <= 0) return;
        float dx = (getWidth() - vW * s) / 2f - vx0 * s;
        float dy = (getHeight() - vH * s) / 2f + 2f * s;

        c.save();
        c.translate(dx, dy);

        Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
        Paint line = new Paint(Paint.ANTI_ALIAS_FLAG);
        line.setStyle(Paint.Style.STROKE);

        // tail
        if (st.includeTail) {
            float tx = st.tailLeft ? 0f : st.labelWidth;
            fill.setColor(0xFFC9C2B0);
            c.drawRect(tx * s, H * 0.42f * s, (tx + st.tailLength) * s, H * 0.58f * s, fill);
        }
        // label body
        fill.setColor(Color.WHITE);
        c.drawRect(lx * s, 0, (lx + st.labelWidth) * s, H * s, fill);
        line.setColor(0xFF8A8A8A);
        line.setStrokeWidth(Math.max(1f, 0.15f * s));
        c.drawRect(lx * s, 0, (lx + st.labelWidth) * s, H * s, line);
        // fold line
        if (st.fold) {
            line.setPathEffect(new DashPathEffect(new float[]{0.8f * s, 0.6f * s}, 0));
            float fx = (lx + st.labelWidth / 2f) * s;
            c.drawLine(fx, 0, fx, H * s, line);
            line.setPathEffect(null);
        }

        // printed content
        LabelRenderer.draw(c, s, st, a, b, qr, bar, false);

        // printable-area frame (where the printer will print, after offset)
        line.setColor(0xCCD32F2F);
        line.setStrokeWidth(Math.max(1f, 0.12f * s));
        line.setPathEffect(new DashPathEffect(new float[]{0.5f * s, 0.4f * s}, 0));
        float ox = lx + st.offsetX, oy = st.offsetY;
        c.drawRect(ox * s, oy * s, (ox + st.labelWidth) * s, (oy + H) * s, line);
        c.restore();

        Paint hint = new Paint(Paint.ANTI_ALIAS_FLAG);
        hint.setColor(0xFF6D6D6D);
        hint.setTextSize(getResources().getDisplayMetrics().density * 11f);
        hint.setTextAlign(Paint.Align.CENTER);
        c.drawText(zoomLabel ? "برای دیدن کل لیبل و دم، لمس کنید" : "برای بزرگ‌نمایی لیبل، لمس کنید",
                getWidth() / 2f, getHeight() - hint.descent() - 4, hint);
    }
}
