package ir.goldlabel;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.graphics.pdf.PdfDocument;
import android.print.PrintAttributes;

import com.google.zxing.EncodeHintType;
import com.google.zxing.oned.Code128Writer;
import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel;
import com.google.zxing.qrcode.encoder.ByteMatrix;
import com.google.zxing.qrcode.encoder.Encoder;
import com.google.zxing.qrcode.encoder.QRCode;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Draws the label. Every coordinate is in mm and multiplied by s (pixels-or-points per mm). */
public final class LabelRenderer {
    public static final float PT_PER_MM = 72f / 25.4f;

    private LabelRenderer() {}

    public static float pageWidth(LabelSettings st) {
        return st.labelWidth + (st.includeTail ? st.tailLength : 0f);
    }

    /** x position (mm) of the label body inside the page. */
    public static float labelX(LabelSettings st) {
        return (st.includeTail && st.tailLeft) ? st.tailLength : 0f;
    }

    public static PrintAttributes.MediaSize mediaSize(LabelSettings st) {
        float w = pageWidth(st), h = st.labelHeight;
        if (st.rotatePage) { float t = w; w = h; h = t; }
        int wm = Math.round(w / 25.4f * 1000f);
        int hm = Math.round(h / 25.4f * 1000f);
        String name = String.format(Locale.US, "Label %.1f x %.1f mm", w, h);
        return new PrintAttributes.MediaSize("GOLD_LABEL_" + wm + "x" + hm, name, wm, hm);
    }

    public static void writePdf(OutputStream os, LabelSettings st, String a, String b,
                                int copies, boolean test) throws IOException {
        PdfDocument doc = new PdfDocument();
        try {
            float s = PT_PER_MM;
            int pw = Math.round(pageWidth(st) * s);
            int ph = Math.round(st.labelHeight * s);
            if (st.rotatePage) { int t = pw; pw = ph; ph = t; }
            for (int i = 0; i < Math.max(1, copies); i++) {
                PdfDocument.PageInfo info = new PdfDocument.PageInfo.Builder(pw, ph, i + 1).create();
                PdfDocument.Page page = doc.startPage(info);
                Canvas c = page.getCanvas();
                if (st.rotatePage) {
                    c.translate(pw, 0);
                    c.rotate(90);
                }
                draw(c, s, st, a, b, test);
                doc.finishPage(page);
            }
            doc.writeTo(os);
        } finally {
            doc.close();
        }
    }

    /** Draws the printed content (with offsets applied). */
    public static void draw(Canvas c, float s, LabelSettings st, String a, String b, boolean test) {
        draw(c, s, st, a, b, null, null, test);
    }

    /** a/b = text of each half, qr/bar = QR and barcode contents (used by halves of that type). */
    public static void draw(Canvas c, float s, LabelSettings st, String a, String b, String qr, String bar,
                            boolean test) {
        float lx = labelX(st) + st.offsetX;
        float ly = st.offsetY;
        float lw = st.labelWidth, lh = st.labelHeight;

        if (test || st.printBorder) {
            Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
            p.setColor(Color.BLACK);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(0.25f * s);
            float h = 0.125f; // half stroke so the line stays inside the label
            c.drawRect((lx + h) * s, (ly + h) * s, (lx + lw - h) * s, (ly + lh - h) * s, p);
            if (st.fold) c.drawLine((lx + lw / 2) * s, ly * s, (lx + lw / 2) * s, (ly + lh) * s, p);
        }

        if (test) {
            drawTestHalf(c, s, st, lx, ly, st.fold ? lw / 2 : lw, lh, "A");
            if (st.fold) drawTestHalf(c, s, st, lx + lw / 2, ly, lw / 2, lh, "B");
            return;
        }

        if (st.fold) {
            drawHalf(c, s, st, lx, ly, lw / 2, lh, st.typeA, a, st.alignA, qr, bar, false);
            drawHalf(c, s, st, lx + lw / 2, ly, lw / 2, lh, st.typeB, b, st.alignB, qr, bar, st.rotateBack);
        } else {
            drawHalf(c, s, st, lx, ly, lw, lh, st.typeA, a, st.alignA, qr, bar, false);
        }
    }

    private static void drawHalf(Canvas c, float s, LabelSettings st, float x, float y, float w, float h,
                                 int type, String text, int align, String qr, String bar, boolean rot) {
        c.save();
        if (rot) c.rotate(180, (x + w / 2) * s, (y + h / 2) * s);
        float pad = st.padding;
        switch (type) {
            case LabelSettings.T_QR:
                drawQr(c, s, st, x, y, w, h, qr);
                break;
            case LabelSettings.T_BAR:
                drawBar(c, s, st, x, y, w, h, bar);
                break;
            case LabelSettings.T_QR_TEXT: {
                float q = Math.min(h, w * 0.6f);
                drawQr(c, s, st, x, y, q, h, qr);
                drawBlock(c, s, st, x + q - pad, y, w - q + pad, h, text, false, align);
                break;
            }
            case LabelSettings.T_BAR_TEXT: {
                float hb = h * 0.58f;
                drawBar(c, s, st, x, y, w, hb, bar);
                drawBlock(c, s, st, x, y + hb - pad, w, h - hb + pad, text, false, align);
                break;
            }
            default:
                drawBlock(c, s, st, x, y, w, h, text, false, align);
        }
        c.restore();
    }

    private static void drawBar(Canvas c, float s, LabelSettings st, float x, float y, float w, float h,
                                String content) {
        if (content == null || content.trim().isEmpty()) return;
        boolean[] code;
        try {
            code = new Code128Writer().encode(content.trim());
        } catch (Exception e) {
            drawBlock(c, s, st, x, y, w, h, "بارکد؟", false);
            return;
        }
        int n = code.length;
        float pad = st.padding;
        float availW = (w - 2 * pad) * s, availH = (h - 2 * pad) * s;
        if (availW <= 0 || availH <= 0 || n == 0) return;
        float mod = (float) Math.floor(availW / n); // whole printer dots per bar module
        if (mod < 1) mod = availW / n;
        float total = mod * n;
        float x0 = (float) Math.floor((x + w / 2) * s - total / 2);
        float y0 = (y + pad) * s;
        Paint p = new Paint();
        p.setColor(Color.BLACK);
        p.setStyle(Paint.Style.FILL);
        p.setAntiAlias(false);
        int i = 0;
        while (i < n) {
            if (code[i]) {
                int j = i;
                while (j < n && code[j]) j++;
                c.drawRect(x0 + i * mod, y0, x0 + j * mod, y0 + availH, p);
                i = j;
            } else {
                i++;
            }
        }
    }

    private static String qrKey;
    private static ByteMatrix qrCache;

    static synchronized ByteMatrix qrMatrix(String content) {
        if (content.equals(qrKey)) return qrCache;
        ByteMatrix m = null;
        try {
            Map<EncodeHintType, Object> h = new HashMap<>();
            h.put(EncodeHintType.CHARACTER_SET, "UTF-8");
            QRCode q = Encoder.encode(content, ErrorCorrectionLevel.M, h);
            if (q.getVersion().getVersionNumber() > 1) {
                QRCode l = Encoder.encode(content, ErrorCorrectionLevel.L, h);
                if (l.getVersion().getVersionNumber() < q.getVersion().getVersionNumber()) q = l;
            }
            m = q.getMatrix();
        } catch (Exception ignored) {
        }
        qrKey = content;
        qrCache = m;
        return m;
    }

    private static void drawQr(Canvas c, float s, LabelSettings st, float x, float y, float w, float h,
                               String content) {
        if (content == null || content.isEmpty()) return;
        ByteMatrix m = qrMatrix(content);
        if (m == null) {
            drawBlock(c, s, st, x, y, w, h, "QR?", false);
            return;
        }
        int n = m.getWidth();
        float avail = Math.min(w, h) - 2 * st.padding;
        if (avail <= 0) return;
        float availPx = avail * s;
        float mod = (float) Math.floor(availPx / n); // whole printer dots per module = sharp QR
        if (mod < 1) mod = availPx / n;
        float size = mod * n;
        float x0 = (float) Math.floor((x + w / 2) * s - size / 2);
        float y0 = (float) Math.floor((y + h / 2) * s - size / 2);
        Paint p = new Paint();
        p.setColor(Color.BLACK);
        p.setStyle(Paint.Style.FILL);
        p.setAntiAlias(false);
        for (int yy = 0; yy < n; yy++) {
            for (int xx = 0; xx < n; xx++) {
                if (m.get(xx, yy) == 1) {
                    c.drawRect(x0 + xx * mod, y0 + yy * mod, x0 + (xx + 1) * mod, y0 + (yy + 1) * mod, p);
                }
            }
        }
    }

    private static void drawTestHalf(Canvas c, float s, LabelSettings st, float x, float y,
                                     float w, float h, String tag) {
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setColor(Color.BLACK);
        p.setStrokeWidth(0.15f * s);
        float cx = x + w / 2, cy = y + h / 2;
        c.drawLine((cx - 1.5f) * s, cy * s, (cx + 1.5f) * s, cy * s, p);
        c.drawLine(cx * s, (cy - 1.5f) * s, cx * s, (cy + 1.5f) * s, p);
        String info = tag + "  X:" + fmt(st.offsetX) + "  Y:" + fmt(st.offsetY);
        drawBlock(c, s, st, x, y, w, h * 0.45f, info, false);
    }

    private static void drawBlock(Canvas c, float s, LabelSettings st, float x, float y,
                                  float w, float h, String text, boolean rotate180) {
        drawBlock(c, s, st, x, y, w, h, text, rotate180, 0);
    }

    /** align: 0 center, 1 right, 2 left. A line starting with # is printed larger and bold. */
    private static void drawBlock(Canvas c, float s, LabelSettings st, float x, float y,
                                  float w, float h, String text, boolean rotate180, int align) {
        if (text == null) return;
        String t = st.persianDigits ? toPersianDigits(text) : text;
        List<String> lines = new ArrayList<>();
        for (String l : t.split("\n")) lines.add(l.trim());
        while (!lines.isEmpty() && lines.get(lines.size() - 1).isEmpty()) lines.remove(lines.size() - 1);
        int n = lines.size();
        if (n == 0) return;

        float pad = st.padding;
        float availW = w - 2 * pad, availH = h - 2 * pad;
        if (availW <= 0 || availH <= 0) return;

        final float k = 1.15f; // line height factor
        final float big = 1.35f;
        float[] wgt = new float[n];
        float sum = 0;
        for (int i = 0; i < n; i++) {
            wgt[i] = lines.get(i).startsWith("#") ? big : 1f;
            sum += wgt[i];
        }
        float unit = Math.min(st.fontSize * k, availH / sum);
        float top = y + pad + (availH - unit * sum) / 2f;

        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.SUBPIXEL_TEXT_FLAG);
        p.setColor(Color.BLACK);
        float tx;
        if (align == 1) { p.setTextAlign(Paint.Align.RIGHT); tx = (x + w - pad) * s; }
        else if (align == 2) { p.setTextAlign(Paint.Align.LEFT); tx = (x + pad) * s; }
        else { p.setTextAlign(Paint.Align.CENTER); tx = (x + w / 2) * s; }

        c.save();
        if (rotate180) c.rotate(180, (x + w / 2) * s, (y + h / 2) * s);
        float cur = top;
        for (int i = 0; i < n; i++) {
            String line = lines.get(i);
            float lineH = unit * wgt[i];
            boolean isBig = wgt[i] > 1f;
            if (isBig) line = line.substring(1).trim();
            if (!line.isEmpty()) {
                p.setTypeface(st.bold || isBig ? Typeface.DEFAULT_BOLD : Typeface.DEFAULT);
                float size = (lineH / k) * s;
                p.setTextSize(size);
                float tw = p.measureText(line);
                if (tw > availW * s) p.setTextSize(size * (availW * s) / tw);
                Paint.FontMetrics fm = p.getFontMetrics();
                float cy = (cur + lineH / 2f) * s;
                float baseline = cy - (fm.ascent + fm.descent) / 2f;
                c.drawText(line, tx, baseline, p);
            }
            cur += lineH;
        }
        c.restore();
    }

    public static String toPersianDigits(String in) {
        StringBuilder sb = new StringBuilder(in.length());
        for (int i = 0; i < in.length(); i++) {
            char ch = in.charAt(i);
            if (ch >= '0' && ch <= '9') sb.append((char) ('۰' + (ch - '0')));
            else sb.append(ch);
        }
        return sb.toString();
    }

    public static String fmt(float v) {
        float r = Math.round(v * 100f) / 100f;
        if (r == 0f) return "0";
        if (r == (long) r) return String.valueOf((long) r);
        String str = String.format(Locale.US, "%.2f", r);
        while (str.endsWith("0")) str = str.substring(0, str.length() - 1);
        return str;
    }
}
