package ir.goldlabel;

import android.app.Activity;

import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.Socket;

/** Raw TCP printing (port 9100) to a network / Wi-Fi printer or print server. */
public final class NetPrinter {
    private NetPrinter() {}

    public static void send(final Activity act, final String host, final int port, final byte[] data,
                            final UsbPrinter.Callback cb) {
        new Thread(new Runnable() {
            public void run() {
                String err = null;
                Socket s = null;
                try {
                    s = new Socket();
                    s.connect(new InetSocketAddress(host, port), 5000);
                    s.setSoTimeout(10000);
                    OutputStream o = s.getOutputStream();
                    o.write(data);
                    o.flush();
                    Thread.sleep(300);
                } catch (Exception e) {
                    err = "اتصال به چاپگر شبکه (" + host + ":" + port + ") ممکن نشد.\n"
                            + "گوشی و چاپگر باید به یک مودم وصل باشند و IP درست باشد.";
                } finally {
                    try { if (s != null) s.close(); } catch (Exception ignored) {}
                }
                final String fe = err;
                act.runOnUiThread(new Runnable() {
                    public void run() { cb.onResult(fe == null, fe); }
                });
            }
        }).start();
    }
}
