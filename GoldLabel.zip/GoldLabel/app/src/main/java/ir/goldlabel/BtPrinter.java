package ir.goldlabel;

import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.pm.PackageManager;
import android.os.Build;

import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/** Bluetooth Classic (SPP) printing for printers with built-in Bluetooth. */
public final class BtPrinter {
    private static final UUID SPP = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");
    private static final String PERM = "android.permission.BLUETOOTH_CONNECT";

    private BtPrinter() {}

    public static boolean needPermission(Activity a) {
        return Build.VERSION.SDK_INT >= 31 && a.checkSelfPermission(PERM) != PackageManager.PERMISSION_GRANTED;
    }

    public static void askPermission(Activity a) {
        if (Build.VERSION.SDK_INT >= 31) a.requestPermissions(new String[]{PERM}, 77);
    }

    /** Paired devices; null if Bluetooth missing/off. */
    public static List<BluetoothDevice> bonded() {
        BluetoothAdapter ad = BluetoothAdapter.getDefaultAdapter();
        if (ad == null || !ad.isEnabled()) return null;
        try {
            return new ArrayList<>(ad.getBondedDevices());
        } catch (SecurityException e) {
            return new ArrayList<>();
        }
    }

    public static String name(BluetoothDevice d) {
        try {
            String n = d.getName();
            return n == null ? d.getAddress() : n;
        } catch (SecurityException e) {
            return d.getAddress();
        }
    }

    public static void send(final Activity act, final String address, final byte[] data,
                            final UsbPrinter.Callback cb) {
        new Thread(new Runnable() {
            public void run() {
                String err = null;
                BluetoothSocket s = null;
                try {
                    BluetoothAdapter ad = BluetoothAdapter.getDefaultAdapter();
                    if (ad == null || !ad.isEnabled()) throw new IllegalStateException("بلوتوث گوشی خاموش است.");
                    try { ad.cancelDiscovery(); } catch (SecurityException ignored) {}
                    BluetoothDevice d = ad.getRemoteDevice(address);
                    try {
                        s = d.createRfcommSocketToServiceRecord(SPP);
                        s.connect();
                    } catch (Exception first) {
                        try { if (s != null) s.close(); } catch (Exception ignored) {}
                        s = d.createInsecureRfcommSocketToServiceRecord(SPP);
                        s.connect();
                    }
                    OutputStream o = s.getOutputStream();
                    int off = 0;
                    while (off < data.length) {
                        int len = Math.min(1024, data.length - off);
                        o.write(data, off, len);
                        off += len;
                    }
                    o.flush();
                    Thread.sleep(600);
                } catch (IllegalStateException e) {
                    err = e.getMessage();
                } catch (SecurityException e) {
                    err = "اجازه بلوتوث داده نشده است.";
                } catch (Exception e) {
                    err = "اتصال بلوتوث به چاپگر ممکن نشد. چاپگر روشن و جفت (Pair) شده باشد.";
                } finally {
                    try { if (s != null) s.close(); } catch (Exception ignored) {}
                }
                final String fe = err;
                act.runOnUiThread(new Runnable() {
                    public void run() { cb.onResult(fe == null, fe); }
                });
            }
        }).start();
    }
}
