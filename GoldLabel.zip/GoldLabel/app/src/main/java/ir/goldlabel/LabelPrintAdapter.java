package ir.goldlabel;

import android.os.Bundle;
import android.os.CancellationSignal;
import android.os.ParcelFileDescriptor;
import android.print.PageRange;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import android.print.PrintDocumentInfo;

import java.io.FileOutputStream;

public class LabelPrintAdapter extends PrintDocumentAdapter {
    private final LabelSettings st;
    private final String a, b;
    private final int copies;
    private final boolean test;

    public LabelPrintAdapter(LabelSettings st, String a, String b, int copies, boolean test) {
        this.st = st;
        this.a = a;
        this.b = b;
        this.copies = Math.max(1, copies);
        this.test = test;
    }

    @Override
    public void onLayout(PrintAttributes oldAttributes, PrintAttributes newAttributes,
                         CancellationSignal cancellationSignal, LayoutResultCallback callback,
                         Bundle extras) {
        if (cancellationSignal.isCanceled()) {
            callback.onLayoutCancelled();
            return;
        }
        PrintDocumentInfo info = new PrintDocumentInfo.Builder("gold_label.pdf")
                .setContentType(PrintDocumentInfo.CONTENT_TYPE_DOCUMENT)
                .setPageCount(copies)
                .build();
        callback.onLayoutFinished(info, true);
    }

    @Override
    public void onWrite(PageRange[] pages, ParcelFileDescriptor destination,
                        CancellationSignal cancellationSignal, WriteResultCallback callback) {
        FileOutputStream fos = null;
        try {
            fos = new FileOutputStream(destination.getFileDescriptor());
            LabelRenderer.writePdf(fos, st, a, b, copies, test);
            if (cancellationSignal.isCanceled()) {
                callback.onWriteCancelled();
                return;
            }
            callback.onWriteFinished(new PageRange[]{PageRange.ALL_PAGES});
        } catch (Exception e) {
            callback.onWriteFailed(e.getMessage());
        } finally {
            if (fos != null) {
                try { fos.close(); } catch (Exception ignored) {}
            }
        }
    }
}
