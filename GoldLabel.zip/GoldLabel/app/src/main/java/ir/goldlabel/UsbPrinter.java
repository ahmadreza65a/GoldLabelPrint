package ir.goldlabel;

import android.app.Activity;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.hardware.usb.UsbConstants;
import android.hardware.usb.UsbDevice;
import android.hardware.usb.UsbDeviceConnection;
import android.hardware.usb.UsbEndpoint;
import android.hardware.usb.UsbInterface;
import android.hardware.usb.UsbManager;
import android.os.Build;

import java.util.Locale;

/** Sends raw bytes to a USB printer over OTG. No Android driver/print-service needed. */
public class UsbPrinter {
    public interface Callback { void onResult(boolean ok, String msg); }

    private static final String ACTION_PERM = "ir.goldlabel.USB_PERMISSION";

    private final Activity act;
    private final UsbManager um;

    public UsbPrinter(Activity a) {
        act = a;
        um = (UsbManager) a.getSystemService(Context.USB_SERVICE);
    }

    private static class Ep {
        UsbInterface iface;
        UsbEndpoint out;
    }

    private static Ep findOut(UsbDevice d) {
        Ep fallback = null;
        for (int i = 0; i < d.getInterfaceCount(); i++) {
            UsbInterface itf = d.getInterface(i);
            for (int j = 0; j < itf.getEndpointCount(); j++) {
                UsbEndpoint e = itf.getEndpoint(j);
                if (e.getType() == UsbConstants.USB_ENDPOINT_XFER_BULK
                        && e.getDirection() == UsbConstants.USB_DIR_OUT) {
                    Ep ep = new Ep();
                    ep.iface = itf;
                    ep.out = e;
                    if (itf.getInterfaceClass() == UsbConstants.USB_CLASS_PRINTER) return ep;
                    if (fallback == null) fallback = ep;
                }
            }
        }
        return fallback;
    }

    private static boolean isPrinter(UsbDevice d) {
        if (d.getDeviceClass() == UsbConstants.USB_CLASS_PRINTER) return true;
        for (int i = 0; i < d.getInterfaceCount(); i++) {
            if (d.getInterface(i).getInterfaceClass() == UsbConstants.USB_CLASS_PRINTER) return true;
        }
        return false;
    }

    public UsbDevice find() {
        if (um == null) return null;
        UsbDevice best = null;
        for (UsbDevice d : um.getDeviceList().values()) {
            if (findOut(d) == null) continue;
            if (isPrinter(d)) return d;
            if (best == null) best = d;
        }
        return best;
    }

    public static String describe(UsbDevice d) {
        String name = null;
        if (Build.VERSION.SDK_INT >= 21) {
            String m = d.getManufacturerName(), p = d.getProductName();
            name = ((m == null ? "" : m + " ") + (p == null ? "" : p)).trim();
        }
        if (name == null || name.isEmpty()) name = "USB";
        return String.format(Locale.US, "%s  (VID:%04X PID:%04X)", name, d.getVendorId(), d.getProductId());
    }

    public void send(final byte[] data, final Callback cb) {
        final UsbDevice d = find();
        if (d == null) {
            cb.onResult(false, "چاپگری با کابل USB پیدا نشد. کابل OTG و روشن بودن چاپگر را بررسی کنید.");
            return;
        }
        if (!um.hasPermission(d)) {
            requestPermission(d, new Callback() {
                public void onResult(boolean ok, String msg) {
                    if (ok) write(d, data, cb);
                    else cb.onResult(false, "اجازه دسترسی به چاپگر داده نشد.");
                }
            });
            return;
        }
        write(d, data, cb);
    }

    private void requestPermission(UsbDevice d, final Callback cb) {
        final BroadcastReceiver r = new BroadcastReceiver() {
            @Override
            public void onReceive(Context ctx, Intent intent) {
                try { act.unregisterReceiver(this); } catch (Exception ignored) {}
                boolean granted = intent.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED, false);
                cb.onResult(granted, null);
            }
        };
        IntentFilter f = new IntentFilter(ACTION_PERM);
        if (Build.VERSION.SDK_INT >= 33) act.registerReceiver(r, f, Context.RECEIVER_EXPORTED);
        else act.registerReceiver(r, f);
        Intent i = new Intent(ACTION_PERM);
        i.setPackage(act.getPackageName());
        int flags = Build.VERSION.SDK_INT >= 31 ? PendingIntent.FLAG_MUTABLE : 0;
        PendingIntent pi = PendingIntent.getBroadcast(act, 0, i, flags);
        um.requestPermission(d, pi);
    }

    private void write(final UsbDevice d, final byte[] data, final Callback cb) {
        new Thread(new Runnable() {
            public void run() {
                final String err = doWrite(d, data);
                act.runOnUiThread(new Runnable() {
                    public void run() {
                        if (err == null) cb.onResult(true, "به چاپگر ارسال شد ✓");
                        else cb.onResult(false, err);
                    }
                });
            }
        }).start();
    }

    private String doWrite(UsbDevice d, byte[] data) {
        Ep ep = findOut(d);
        if (ep == null) return "این دستگاه خروجی چاپ ندارد.";
        UsbDeviceConnection c = um.openDevice(d);
        if (c == null) return "باز کردن اتصال USB ممکن نشد.";
        try {
            if (!c.claimInterface(ep.iface, true)) return "چاپگر در اختیار برنامه دیگری است.";
            int off = 0;
            while (off < data.length) {
                int len = Math.min(16384, data.length - off);
                int n = c.bulkTransfer(ep.out, data, off, len, 8000);
                if (n <= 0) return "ارسال داده به چاپگر قطع شد.";
                off += n;
            }
            return null;
        } finally {
            try { c.releaseInterface(ep.iface); } catch (Exception ignored) {}
            c.close();
        }
    }
}
