package ir.goldlabel;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.ColorStateList;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.zxing.integration.android.IntentIntegrator;
import com.google.zxing.integration.android.IntentResult;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.OutputStream;
import java.nio.charset.Charset;
import java.util.Date;
import java.util.Locale;

/** Continuous QR scanning, item list and plain-text report export. */
public class ScanActivity extends Activity {
    private static final String P_ITEMS = "scan_items";
    private static final String P_NODUP = "scan_nodup";
    private static final int REQ_SAVE_TXT = 21;

    private static final int C_DARK = 0xFF2B1D0E;
    private static final int C_BROWN = 0xFF5A3E12;
    private static final int C_GOLD = 0xFFC9A13B;
    private static final int C_GOLD_LIGHT = 0xFFF1D78A;
    private static final int C_GOLD_DEEP = 0xFFA97C14;
    private static final int C_BG = 0xFFF6F1E6;
    private static final int C_TEXT = 0xFF33270F;
    private static final int C_MUTED = 0xFF8A7B5C;

    private SharedPreferences prefs;
    private JSONArray items = new JSONArray();
    private LinearLayout listBox;
    private TextView tvSummary;
    private CheckBox cbNoDup;
    private String lastMsg = "";

    // ---------------------------------------------------------------- lifecycle

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(C_DARK);
        getWindow().setNavigationBarColor(C_DARK);
        prefs = getSharedPreferences("gold_label", MODE_PRIVATE);
        try {
            items = new JSONArray(prefs.getString(P_ITEMS, "[]"));
        } catch (Exception e) {
            items = new JSONArray();
        }
        buildUi();
        render();
    }

    private void saveItems() {
        prefs.edit().putString(P_ITEMS, items.toString()).apply();
    }

    // ---------------------------------------------------------------- UI

    private int dp(float v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    private GradientDrawable round(int color, float r, int stroke) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(r));
        if (stroke != 0) g.setStroke(dp(1), stroke);
        return g;
    }

    private Button btn(String text, boolean gold, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setStateListAnimator(null);
        b.setTypeface(Typeface.DEFAULT_BOLD);
        b.setTextSize(15);
        b.setMinHeight(dp(52));
        GradientDrawable g;
        if (gold) {
            g = new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[]{C_GOLD_LIGHT, C_GOLD, C_GOLD_DEEP});
            b.setTextColor(C_DARK);
        } else {
            g = new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[]{C_BROWN, C_DARK});
            b.setTextColor(C_GOLD_LIGHT);
        }
        g.setCornerRadius(dp(14));
        b.setBackground(new RippleDrawable(ColorStateList.valueOf(0x44FFFFFF), g, null));
        b.setOnClickListener(l);
        return b;
    }

    private Button outline(String text, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setStateListAnimator(null);
        b.setTextSize(14);
        b.setTextColor(C_BROWN);
        b.setBackground(new RippleDrawable(ColorStateList.valueOf(0x33C9A13B), round(0xFFFFFCF5, 14, C_GOLD), null));
        b.setOnClickListener(l);
        return b;
    }

    private LinearLayout.LayoutParams lp(int top) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        p.topMargin = dp(top);
        return p;
    }

    private void buildUi() {
        ScrollView sv = new ScrollView(this);
        sv.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        sv.setBackgroundColor(C_BG);
        sv.setFillViewport(true);
        LinearLayout outer = new LinearLayout(this);
        outer.setOrientation(LinearLayout.VERTICAL);
        sv.addView(outer);

        LinearLayout h = new LinearLayout(this);
        h.setOrientation(LinearLayout.VERTICAL);
        GradientDrawable hg = new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{C_DARK, C_BROWN, 0xFF7A5A1C});
        float r = dp(26);
        hg.setCornerRadii(new float[]{0, 0, 0, 0, r, r, r, r});
        h.setBackground(hg);
        h.setPadding(dp(20), dp(16), dp(20), dp(18));
        TextView t = new TextView(this);
        t.setText("📷  اسکن و ثبت کالاها");
        t.setTextSize(21);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setTextColor(C_GOLD_LIGHT);
        t.setGravity(Gravity.CENTER);
        h.addView(t);
        TextView sub = new TextView(this);
        sub.setText("گالری طلا روح‌اله انصاری");
        sub.setTextColor(0xFFE8DCC0);
        sub.setGravity(Gravity.CENTER);
        sub.setPadding(0, dp(4), 0, 0);
        h.addView(sub);
        outer.addView(h);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(14), dp(14), dp(14), dp(28));
        outer.addView(root);

        Button scan = btn("📷   شروع اسکن", true, new View.OnClickListener() {
            public void onClick(View v) { lastMsg = ""; startScan(); }
        });
        scan.setTextSize(19);
        scan.setMinHeight(dp(62));
        root.addView(scan, lp(0));

        TextView hint = new TextView(this);
        hint.setText("لیبل‌ها را یکی‌یکی جلوی دوربین بگیرید؛ هر کد خودکار ثبت می‌شود و اسکن بعدی شروع می‌شود. برای پایان، دکمه برگشت گوشی را بزنید.");
        hint.setTextColor(C_MUTED);
        hint.setTextSize(12.5f);
        hint.setPadding(0, dp(6), 0, 0);
        root.addView(hint);

        cbNoDup = new CheckBox(this);
        cbNoDup.setText("کد تکراری ثبت نشود");
        cbNoDup.setTextColor(C_TEXT);
        cbNoDup.setChecked(prefs.getBoolean(P_NODUP, true));
        cbNoDup.setOnCheckedChangeListener((b, v) -> prefs.edit().putBoolean(P_NODUP, v).apply());
        root.addView(cbNoDup, lp(4));

        tvSummary = new TextView(this);
        tvSummary.setTextSize(15);
        tvSummary.setTypeface(Typeface.DEFAULT_BOLD);
        tvSummary.setTextColor(C_BROWN);
        tvSummary.setGravity(Gravity.CENTER);
        tvSummary.setBackground(round(0xFFFBF3DD, 12, 0));
        tvSummary.setPadding(dp(10), dp(10), dp(10), dp(10));
        root.addView(tvSummary, lp(8));

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        Button save = btn("💾  ذخیره فایل متنی", false, new View.OnClickListener() {
            public void onClick(View v) { saveTxt(); }
        });
        Button share = btn("📤  ارسال", false, new View.OnClickListener() {
            public void onClick(View v) { shareTxt(); }
        });
        LinearLayout.LayoutParams a = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1.4f);
        LinearLayout.LayoutParams b = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        b.setMarginStart(dp(8));
        row.addView(save, a);
        row.addView(share, b);
        root.addView(row, lp(10));

        root.addView(outline("🗑  پاک کردن کل فهرست", new View.OnClickListener() {
            public void onClick(View v) { clearAll(); }
        }), lp(8));

        listBox = new LinearLayout(this);
        listBox.setOrientation(LinearLayout.VERTICAL);
        root.addView(listBox, lp(12));

        setContentView(sv);
    }

    private void render() {
        listBox.removeAllViews();
        tvSummary.setText("تعداد: " + items.length() + "    جمع وزن: " + fmt3(totalWeight()) + " گرم");
        if (items.length() == 0) {
            TextView e = new TextView(this);
            e.setText("هنوز کالایی اسکن نشده.");
            e.setTextColor(C_MUTED);
            e.setGravity(Gravity.CENTER);
            e.setPadding(0, dp(20), 0, 0);
            listBox.addView(e);
            return;
        }
        for (int i = items.length() - 1; i >= 0; i--) {
            final int idx = i;
            JSONObject o = items.optJSONObject(i);
            if (o == null) continue;
            TextView tv = new TextView(this);
            tv.setText((i + 1) + ")  " + line(o, false));
            tv.setTextColor(C_TEXT);
            tv.setTextSize(14);
            tv.setPadding(dp(12), dp(10), dp(12), dp(10));
            tv.setBackground(new RippleDrawable(ColorStateList.valueOf(0x33C9A13B),
                    round(0xFFFFFFFF, 12, 0xFFE8DCBE), null));
            tv.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) { askDelete(idx); }
            });
            listBox.addView(tv, lp(6));
        }
    }

    // ---------------------------------------------------------------- scanning

    private void startScan() {
        IntentIntegrator ii = new IntentIntegrator(this);
        ii.setDesiredBarcodeFormats(IntentIntegrator.QR_CODE);
        String prompt = "تعداد ثبت‌شده: " + items.length() + "   —   برای پایان، برگشت را بزنید";
        if (!lastMsg.isEmpty()) prompt = lastMsg + "\n" + prompt;
        ii.setPrompt(prompt);
        ii.setBeepEnabled(true);
        ii.setOrientationLocked(false);
        ii.initiateScan();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == REQ_SAVE_TXT) {
            if (resultCode == RESULT_OK && data != null && data.getData() != null) writeTxt(data.getData());
            return;
        }
        IntentResult r = IntentIntegrator.parseActivityResult(requestCode, resultCode, data);
        if (r != null) {
            if (r.getContents() == null) {
                render(); // user finished scanning
                return;
            }
            handle(r.getContents());
            render();
            startScan(); // next item
            return;
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    private void handle(String raw) {
        JSONObject o = parse(raw);
        String key = o.optString("code", "");
        if (key.isEmpty()) key = raw;
        if (cbNoDup.isChecked()) {
            for (int i = 0; i < items.length(); i++) {
                JSONObject x = items.optJSONObject(i);
                if (x == null) continue;
                String k = x.optString("code", "");
                if (k.isEmpty()) k = x.optString("raw", "");
                if (k.equals(key)) {
                    lastMsg = "⚠ تکراری بود: " + key;
                    return;
                }
            }
        }
        items.put(o);
        saveItems();
        lastMsg = "✓ ثبت شد: " + key;
    }

    /** Payload printed by the app: CODE/WEIGHT/WAGE/KARAT. Anything else is kept as raw text. */
    private static JSONObject parse(String raw) {
        JSONObject o = new JSONObject();
        try {
            o.put("raw", raw);
            o.put("time", now());
            String[] p = raw.split("/", -1);
            if (p.length >= 4) {
                int n = p.length;
                StringBuilder code = new StringBuilder();
                for (int i = 0; i < n - 3; i++) {
                    if (i > 0) code.append('/');
                    code.append(p[i]);
                }
                o.put("code", code.toString().trim());
                o.put("weight", p[n - 3].trim());
                o.put("wage", p[n - 2].trim());
                o.put("karat", p[n - 1].trim());
            }
        } catch (Exception ignored) {
        }
        return o;
    }

    private void askDelete(final int idx) {
        JSONObject o = items.optJSONObject(idx);
        new AlertDialog.Builder(this)
                .setMessage("این مورد حذف شود؟\n\n" + (o == null ? "" : line(o, false)))
                .setPositiveButton("حذف", (d, w) -> {
                    items.remove(idx);
                    saveItems();
                    render();
                })
                .setNegativeButton("انصراف", null)
                .show();
    }

    private void clearAll() {
        if (items.length() == 0) return;
        new AlertDialog.Builder(this)
                .setMessage("کل فهرست (" + items.length() + " مورد) پاک شود؟\nاگر لازم است اول فایل متنی را ذخیره کنید.")
                .setPositiveButton("پاک شود", (d, w) -> {
                    items = new JSONArray();
                    saveItems();
                    render();
                })
                .setNegativeButton("انصراف", null)
                .show();
    }

    // ---------------------------------------------------------------- report

    private static String line(JSONObject o, boolean withTime) {
        StringBuilder sb = new StringBuilder();
        if (o.has("code")) {
            sb.append("کد: ").append(o.optString("code"));
            String w = o.optString("weight"), g = o.optString("wage"), k = o.optString("karat");
            if (!w.isEmpty()) sb.append("  |  وزن: ").append(w).append(" گرم");
            if (!g.isEmpty()) sb.append("  |  اجرت: ").append(g).append("%");
            if (!k.isEmpty()) sb.append("  |  عیار: ").append(k);
        } else {
            sb.append("متن: ").append(o.optString("raw"));
        }
        if (withTime) sb.append("  |  زمان: ").append(o.optString("time"));
        return sb.toString();
    }

    private double totalWeight() {
        double sum = 0;
        for (int i = 0; i < items.length(); i++) {
            JSONObject o = items.optJSONObject(i);
            if (o == null) continue;
            try { sum += Double.parseDouble(o.optString("weight", "")); } catch (Exception ignored) {}
        }
        return sum;
    }

    private static String fmt3(double v) {
        return String.format(Locale.US, "%.3f", v);
    }

    private static String now() {
        try {
            android.icu.text.SimpleDateFormat f = new android.icu.text.SimpleDateFormat(
                    "yyyy/MM/dd HH:mm", new android.icu.util.ULocale("en_US@calendar=persian"));
            return f.format(new Date());
        } catch (Throwable t) {
            return new java.text.SimpleDateFormat("yyyy/MM/dd HH:mm", Locale.US).format(new Date());
        }
    }

    private String report() {
        StringBuilder sb = new StringBuilder();
        sb.append("گالری طلا روح‌اله انصاری\n");
        sb.append("گزارش اسکن کالا — ").append(now()).append("\n");
        sb.append("تعداد: ").append(items.length())
                .append("    جمع وزن: ").append(fmt3(totalWeight())).append(" گرم\n");
        sb.append("--------------------------------------------------\n");
        for (int i = 0; i < items.length(); i++) {
            JSONObject o = items.optJSONObject(i);
            if (o == null) continue;
            sb.append(i + 1).append(") ").append(line(o, true)).append("\n");
        }
        return sb.toString();
    }

    private void saveTxt() {
        if (items.length() == 0) { toast("فهرست خالی است"); return; }
        Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("text/plain");
        i.putExtra(Intent.EXTRA_TITLE, "scan_" + now().replace('/', '-').replace(' ', '_').replace(":", "") + ".txt");
        try {
            startActivityForResult(i, REQ_SAVE_TXT);
        } catch (Exception e) {
            toast("امکان ذخیره فایل وجود ندارد");
        }
    }

    private void writeTxt(Uri uri) {
        OutputStream os = null;
        try {
            os = getContentResolver().openOutputStream(uri);
            os.write(("﻿" + report()).getBytes(Charset.forName("UTF-8")));
            toast("فایل متنی ذخیره شد ✓");
        } catch (Exception e) {
            toast("خطا در ذخیره: " + e.getMessage());
        } finally {
            if (os != null) {
                try { os.close(); } catch (Exception ignored) {}
            }
        }
    }

    private void shareTxt() {
        if (items.length() == 0) { toast("فهرست خالی است"); return; }
        Intent s = new Intent(Intent.ACTION_SEND);
        s.setType("text/plain");
        s.putExtra(Intent.EXTRA_SUBJECT, "گزارش اسکن کالا");
        s.putExtra(Intent.EXTRA_TEXT, report());
        startActivity(Intent.createChooser(s, "ارسال گزارش"));
    }

    private void toast(String m) {
        Toast.makeText(this, m, Toast.LENGTH_SHORT).show();
    }
}
