package ir.goldlabel;

import org.json.JSONObject;

/** All dimensions are in millimetres. */
public class LabelSettings {
    public float labelWidth = 44f;   // full label width (both halves before folding)
    public float labelHeight = 10f;
    public float tailLength = 45f;
    public float offsetX = 0f;       // + = right
    public float offsetY = 0f;       // + = down
    public float padding = 0.8f;
    public float fontSize = 2.8f;    // text height in mm (auto-shrinks to fit)

    public boolean fold = true;          // label is folded in half (two faces)
    public boolean includeTail = true;   // page includes the tail
    public boolean tailLeft = false;     // tail on the left side of the label
    public boolean rotateBack = false;   // rotate second half 180°
    public boolean rotatePage = false;   // rotate whole page 90°
    public boolean bold = true;
    public boolean persianDigits = false;
    public boolean printBorder = false;

    public LabelSettings copy() {
        LabelSettings s = new LabelSettings();
        s.applyJson(toJson());
        return s;
    }

    public String toJson() {
        try {
            JSONObject o = new JSONObject();
            o.put("labelWidth", labelWidth);
            o.put("labelHeight", labelHeight);
            o.put("tailLength", tailLength);
            o.put("offsetX", offsetX);
            o.put("offsetY", offsetY);
            o.put("padding", padding);
            o.put("fontSize", fontSize);
            o.put("fold", fold);
            o.put("includeTail", includeTail);
            o.put("tailLeft", tailLeft);
            o.put("rotateBack", rotateBack);
            o.put("rotatePage", rotatePage);
            o.put("bold", bold);
            o.put("persianDigits", persianDigits);
            o.put("printBorder", printBorder);
            return o.toString();
        } catch (Exception e) {
            return "{}";
        }
    }

    public void applyJson(String json) {
        LabelSettings d = new LabelSettings();
        try {
            JSONObject o = new JSONObject(json);
            labelWidth = (float) o.optDouble("labelWidth", d.labelWidth);
            labelHeight = (float) o.optDouble("labelHeight", d.labelHeight);
            tailLength = (float) o.optDouble("tailLength", d.tailLength);
            offsetX = (float) o.optDouble("offsetX", d.offsetX);
            offsetY = (float) o.optDouble("offsetY", d.offsetY);
            padding = (float) o.optDouble("padding", d.padding);
            fontSize = (float) o.optDouble("fontSize", d.fontSize);
            fold = o.optBoolean("fold", d.fold);
            includeTail = o.optBoolean("includeTail", d.includeTail);
            tailLeft = o.optBoolean("tailLeft", d.tailLeft);
            rotateBack = o.optBoolean("rotateBack", d.rotateBack);
            rotatePage = o.optBoolean("rotatePage", d.rotatePage);
            bold = o.optBoolean("bold", d.bold);
            persianDigits = o.optBoolean("persianDigits", d.persianDigits);
            printBorder = o.optBoolean("printBorder", d.printBorder);
        } catch (Exception ignored) {
        }
    }
}
