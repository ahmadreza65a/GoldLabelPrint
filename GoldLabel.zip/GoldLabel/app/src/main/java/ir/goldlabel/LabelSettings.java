package ir.goldlabel;

import org.json.JSONObject;

/** All dimensions are in millimetres. */
public class LabelSettings {
    public float labelWidth = 44f;   // full label width (both halves before folding)
    public float labelHeight = 10f;
    public float tailLength = 45f;
    public float offsetX = 0f;       // + = right
    public float offsetY = 0f;       // + = down
    public float padding = 0.8f;
    public float fontSize = 2.8f;    // text height in mm (auto-shrinks to fit)

    public boolean fold = true;          // label is folded in half (two faces)
    public boolean includeTail = true;   // page includes the tail
    public boolean tailLeft = false;     // tail on the left side of the label
    public boolean rotateBack = false;   // rotate second half 180°
    public boolean rotatePage = false;   // rotate whole page 90°
    public boolean bold = true;
    public boolean persianDigits = false;
    public boolean printBorder = false;

    // direct USB printing
    public int usbLang = 0;          // 0 TSPL, 1 ZPL, 2 ESC/POS
    public int dpi = 203;
    public float gapMm = 2f;
    public int density = 8;
    public boolean usbFlip = false;

    // connection: 0 USB, 1 network/Wi-Fi, 2 Bluetooth
    public int conn = 0;
    public String netHost = "192.168.1.100";
    public int netPort = 9100;
    public String btAddress = "";
    public String btName = "";

    // quick-print profile
    public String tplA = "{عیار} عیار\nوزن: {وزن}";
    public String tplB = "{کد}\nاجرت: {اجرت}%";
    public String codePrefix = "N-";
    public int codeStep = 1;
    public boolean clearWeight = true;
    public boolean clearWage = false;

    // template designer: per-half content type
    public static final int T_TEXT = 0, T_QR = 1, T_BAR = 2, T_QR_TEXT = 3, T_BAR_TEXT = 4;
    public int typeA = T_TEXT, typeB = T_TEXT;
    public int alignA = 0, alignB = 0;          // 0 center, 1 right, 2 left
    public String qrTpl = "{کد}/{وزن}/{اجرت}/{عیار}";
    public String barTpl = "{شماره}";
    public String f1Name = "سنگ";
    public String f2Name = "قیمت";

    public LabelSettings copy() {
        LabelSettings s = new LabelSettings();
        s.applyJson(toJson());
        return s;
    }

    public String toJson() {
        try {
            JSONObject o = new JSONObject();
            o.put("labelWidth", labelWidth);
            o.put("labelHeight", labelHeight);
            o.put("tailLength", tailLength);
            o.put("offsetX", offsetX);
            o.put("offsetY", offsetY);
            o.put("padding", padding);
            o.put("fontSize", fontSize);
            o.put("fold", fold);
            o.put("includeTail", includeTail);
            o.put("tailLeft", tailLeft);
            o.put("rotateBack", rotateBack);
            o.put("rotatePage", rotatePage);
            o.put("bold", bold);
            o.put("persianDigits", persianDigits);
            o.put("printBorder", printBorder);
            o.put("usbLang", usbLang);
            o.put("dpi", dpi);
            o.put("gapMm", gapMm);
            o.put("density", density);
            o.put("usbFlip", usbFlip);
            o.put("conn", conn);
            o.put("netHost", netHost);
            o.put("netPort", netPort);
            o.put("btAddress", btAddress);
            o.put("btName", btName);
            o.put("typeA", typeA);
            o.put("typeB", typeB);
            o.put("alignA", alignA);
            o.put("alignB", alignB);
            o.put("qrTpl", qrTpl);
            o.put("barTpl", barTpl);
            o.put("f1Name", f1Name);
            o.put("f2Name", f2Name);
            o.put("tplA", tplA);
            o.put("tplB", tplB);
            o.put("codePrefix", codePrefix);
            o.put("codeStep", codeStep);
            o.put("clearWeight", clearWeight);
            o.put("clearWage", clearWage);
            return o.toString();
        } catch (Exception e) {
            return "{}";
        }
    }

    public void applyJson(String json) {
        LabelSettings d = new LabelSettings();
        try {
            JSONObject o = new JSONObject(json);
            labelWidth = (float) o.optDouble("labelWidth", d.labelWidth);
            labelHeight = (float) o.optDouble("labelHeight", d.labelHeight);
            tailLength = (float) o.optDouble("tailLength", d.tailLength);
            offsetX = (float) o.optDouble("offsetX", d.offsetX);
            offsetY = (float) o.optDouble("offsetY", d.offsetY);
            padding = (float) o.optDouble("padding", d.padding);
            fontSize = (float) o.optDouble("fontSize", d.fontSize);
            fold = o.optBoolean("fold", d.fold);
            includeTail = o.optBoolean("includeTail", d.includeTail);
            tailLeft = o.optBoolean("tailLeft", d.tailLeft);
            rotateBack = o.optBoolean("rotateBack", d.rotateBack);
            rotatePage = o.optBoolean("rotatePage", d.rotatePage);
            bold = o.optBoolean("bold", d.bold);
            persianDigits = o.optBoolean("persianDigits", d.persianDigits);
            printBorder = o.optBoolean("printBorder", d.printBorder);
            usbLang = o.optInt("usbLang", d.usbLang);
            dpi = o.optInt("dpi", d.dpi);
            gapMm = (float) o.optDouble("gapMm", d.gapMm);
            density = o.optInt("density", d.density);
            usbFlip = o.optBoolean("usbFlip", d.usbFlip);
            conn = o.optInt("conn", d.conn);
            netHost = o.optString("netHost", d.netHost);
            netPort = o.optInt("netPort", d.netPort);
            btAddress = o.optString("btAddress", d.btAddress);
            btName = o.optString("btName", d.btName);
            tplA = o.optString("tplA", d.tplA);
            tplB = o.optString("tplB", d.tplB);
            codePrefix = o.optString("codePrefix", d.codePrefix);
            codeStep = o.optInt("codeStep", d.codeStep);
            clearWeight = o.optBoolean("clearWeight", d.clearWeight);
            clearWage = o.optBoolean("clearWage", d.clearWage);
            typeA = o.optInt("typeA", d.typeA);
            typeB = o.optInt("typeB", d.typeB);
            alignA = o.optInt("alignA", d.alignA);
            alignB = o.optInt("alignB", d.alignB);
            qrTpl = o.optString("qrTpl", d.qrTpl);
            barTpl = o.optString("barTpl", d.barTpl);
            f1Name = o.optString("f1Name", d.f1Name);
            f2Name = o.optString("f2Name", d.f2Name);
            // migrate the older "QR mode" profiles
            if (!o.has("typeA") && o.optBoolean("qrMode", false)) {
                String tq = o.optString("tplQr", "{کد}\nاجرت: {اجرت}%\nوزن: {وزن}");
                if (o.optBoolean("qrOnFirst", false)) { typeA = T_QR; typeB = T_TEXT; tplB = tq; }
                else { typeA = T_TEXT; typeB = T_QR; tplA = tq; }
            }
        } catch (Exception ignored) {
        }
    }
}
