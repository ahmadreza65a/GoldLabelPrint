package ir.goldlabel;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.ColorStateList;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.print.PrintAttributes;
import android.print.PrintManager;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONObject;

import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

public class MainActivity extends Activity {
    private static final int REQ_SAVE_PDF = 11;
    private static final String P_DEFAULT = "default_settings";
    private static final String P_PRESETS = "presets";
    private static final String P_TEXT_A = "text_a";
    private static final String P_TEXT_B = "text_b";
    private static final String P_COPIES = "copies";
    private static final String P_STEP = "step";

    // palette
    private static final int C_DARK = 0xFF2B1D0E;
    private static final int C_BROWN = 0xFF5A3E12;
    private static final int C_GOLD = 0xFFC9A13B;
    private static final int C_GOLD_LIGHT = 0xFFF1D78A;
    private static final int C_GOLD_DEEP = 0xFFA97C14;
    private static final int C_BG = 0xFFF6F1E6;
    private static final int C_CARD_STROKE = 0xFFE8DCBE;
    private static final int C_TEXT = 0xFF33270F;
    private static final int C_MUTED = 0xFF8A7B5C;

    private SharedPreferences prefs;
    private final LabelSettings st = new LabelSettings();
    private boolean updating = false;
    private float step = 0.5f;

    private PreviewView preview;
    private EditText etA, etB, etCopies;
    private EditText etW, etH, etTail, etOffX, etOffY, etPad, etFont;
    private CheckBox cbFold, cbTail, cbTailLeft, cbRotB, cbRotPage, cbBold, cbFa, cbBorder;
    private TextView tvOffset;

    // ---------------------------------------------------------------- lifecycle

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(C_DARK);
        getWindow().setNavigationBarColor(C_DARK);
        prefs = getSharedPreferences("gold_label", MODE_PRIVATE);
        String def = prefs.getString(P_DEFAULT, null);
        if (def != null) st.applyJson(def);
        step = prefs.getFloat(P_STEP, 0.5f);
        buildUi();
        settingsToUi();
        updating = true;
        etA.setText(prefs.getString(P_TEXT_A, "18 عیار\nوزن: 2.350"));
        etB.setText(prefs.getString(P_TEXT_B, "کد: 1024\nاجرت: 18%"));
        etCopies.setText(String.valueOf(prefs.getInt(P_COPIES, 1)));
        updating = false;
        refresh();
    }

    @Override
    protected void onPause() {
        super.onPause();
        prefs.edit()
                .putString(P_TEXT_A, etA.getText().toString())
                .putString(P_TEXT_B, etB.getText().toString())
                .putInt(P_COPIES, copies())
                .putFloat(P_STEP, step)
                .apply();
    }

    // ---------------------------------------------------------------- styling helpers

    private int dp(float v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    private GradientDrawable round(int color, float radiusDp, int stroke) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(radiusDp));
        if (stroke != 0) g.setStroke(dp(1), stroke);
        return g;
    }

    private Drawable ripple(Drawable content, int rippleColor) {
        return new RippleDrawable(ColorStateList.valueOf(rippleColor), content, null);
    }

    private LinearLayout vbox() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        return l;
    }

    private LinearLayout hbox() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.HORIZONTAL);
        l.setGravity(Gravity.CENTER_VERTICAL);
        return l;
    }

    private LinearLayout.LayoutParams matchWrap(int topMarginDp) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.topMargin = dp(topMarginDp);
        return lp;
    }

    /** A white rounded card with a gold-accented title. Returns the card body. */
    private LinearLayout card(LinearLayout parent, String icon, String title) {
        LinearLayout c = vbox();
        c.setBackground(round(0xFFFFFFFF, 18, C_CARD_STROKE));
        c.setElevation(dp(3));
        c.setPadding(dp(16), dp(14), dp(16), dp(16));

        LinearLayout head = hbox();
        View bar = new View(this);
        bar.setBackground(round(C_GOLD, 3, 0));
        head.addView(bar, new LinearLayout.LayoutParams(dp(5), dp(22)));
        TextView t = new TextView(this);
        t.setText(icon + "  " + title);
        t.setTextSize(16.5f);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setTextColor(C_TEXT);
        t.setPadding(dp(10), 0, dp(10), 0);
        head.addView(t);
        c.addView(head);

        View div = new View(this);
        div.setBackgroundColor(0xFFF0E7D2);
        LinearLayout.LayoutParams dl = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(1));
        dl.topMargin = dp(10);
        dl.bottomMargin = dp(6);
        c.addView(div, dl);

        parent.addView(c, matchWrap(14));
        return c;
    }

    private TextView note(LinearLayout parent, String text) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextSize(12.5f);
        t.setTextColor(C_MUTED);
        t.setPadding(0, dp(2), 0, dp(6));
        parent.addView(t);
        return t;
    }

    private void styleInput(EditText e) {
        e.setBackground(round(0xFFFBF8F1, 12, 0xFFE3D5B0));
        e.setPadding(dp(12), dp(10), dp(12), dp(10));
        e.setTextColor(C_TEXT);
        e.setHintTextColor(0xFFB5A887);
        e.setTextSize(15);
    }

    private final TextWatcher watcher = new TextWatcher() {
        public void beforeTextChanged(CharSequence s, int a, int b, int c) {}
        public void onTextChanged(CharSequence s, int a, int b, int c) {}
        public void afterTextChanged(Editable e) { onUiChanged(); }
    };

    private final CompoundButton.OnCheckedChangeListener checkListener =
            new CompoundButton.OnCheckedChangeListener() {
                public void onCheckedChanged(CompoundButton b, boolean v) { onUiChanged(); }
            };

    private EditText numField(LinearLayout parent, String label, String unit) {
        LinearLayout row = hbox();
        row.setPadding(0, dp(5), 0, dp(5));
        TextView tv = new TextView(this);
        tv.setText(label);
        tv.setTextSize(14);
        tv.setTextColor(C_TEXT);
        row.addView(tv, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1.5f));
        EditText e = new EditText(this);
        e.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL
                | InputType.TYPE_NUMBER_FLAG_SIGNED);
        e.setGravity(Gravity.CENTER);
        e.setSelectAllOnFocus(true);
        styleInput(e);
        e.setTypeface(Typeface.DEFAULT_BOLD);
        e.addTextChangedListener(watcher);
        row.addView(e, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        if (unit != null) {
            TextView u = new TextView(this);
            u.setText(unit);
            u.setTextSize(12);
            u.setTextColor(C_MUTED);
            u.setPadding(dp(6), 0, 0, 0);
            row.addView(u, new LinearLayout.LayoutParams(dp(30), ViewGroup.LayoutParams.WRAP_CONTENT));
        }
        parent.addView(row);
        return e;
    }

    private CheckBox check(LinearLayout parent, String label) {
        CheckBox cb = new CheckBox(this);
        cb.setText(label);
        cb.setTextSize(14);
        cb.setTextColor(C_TEXT);
        cb.setPadding(dp(4), dp(6), dp(4), dp(6));
        cb.setOnCheckedChangeListener(checkListener);
        parent.addView(cb);
        return cb;
    }

    private Button baseButton(String text, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setTextSize(14.5f);
        b.setStateListAnimator(null);
        b.setMinHeight(dp(48));
        b.setPadding(dp(10), dp(8), dp(10), dp(8));
        b.setOnClickListener(l);
        return b;
    }

    /** Gold gradient, the main action. */
    private Button primary(String text, View.OnClickListener l) {
        Button b = baseButton(text, l);
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{C_GOLD_LIGHT, C_GOLD, C_GOLD_DEEP});
        g.setCornerRadius(dp(14));
        b.setBackground(ripple(g, 0x55FFFFFF));
        b.setTextColor(C_DARK);
        b.setTypeface(Typeface.DEFAULT_BOLD);
        b.setElevation(dp(3));
        return b;
    }

    /** Dark brown, secondary strong action. */
    private Button dark(String text, View.OnClickListener l) {
        Button b = baseButton(text, l);
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{C_BROWN, C_DARK});
        g.setCornerRadius(dp(14));
        b.setBackground(ripple(g, 0x44F1D78A));
        b.setTextColor(C_GOLD_LIGHT);
        b.setTypeface(Typeface.DEFAULT_BOLD);
        return b;
    }

    /** Outlined, light action. */
    private Button outline(String text, View.OnClickListener l) {
        Button b = baseButton(text, l);
        b.setBackground(ripple(round(0xFFFFFCF5, 14, C_GOLD), 0x33C9A13B));
        b.setTextColor(C_BROWN);
        return b;
    }

    private void buttonRow(LinearLayout parent, int topDp, Button... buttons) {
        LinearLayout row = hbox();
        for (int i = 0; i < buttons.length; i++) {
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
            if (i > 0) lp.setMarginStart(dp(8));
            row.addView(buttons[i], lp);
        }
        parent.addView(row, matchWrap(topDp));
    }

    // ---------------------------------------------------------------- UI build

    private View header() {
        LinearLayout h = vbox();
        h.setGravity(Gravity.CENTER_HORIZONTAL);
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{C_DARK, C_BROWN, 0xFF7A5A1C});
        float r = dp(28);
        g.setCornerRadii(new float[]{0, 0, 0, 0, r, r, r, r});
        h.setBackground(g);
        h.setPadding(dp(20), dp(26), dp(20), dp(26));
        h.setElevation(dp(6));

        TextView gem = new TextView(this);
        gem.setText("◆");
        gem.setTextSize(22);
        gem.setTextColor(C_GOLD_LIGHT);
        gem.setGravity(Gravity.CENTER);
        h.addView(gem);

        TextView t = new TextView(this);
        t.setText("گالری طلا روح‌اله انصاری");
        t.setTextSize(24);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setTextColor(C_GOLD_LIGHT);
        t.setGravity(Gravity.CENTER);
        t.setShadowLayer(dp(4), 0, dp(1), 0x66000000);
        t.setPadding(0, dp(4), 0, dp(4));
        h.addView(t);

        LinearLayout line = hbox();
        line.setGravity(Gravity.CENTER);
        View l1 = new View(this);
        l1.setBackgroundColor(0x99C9A13B);
        View l2 = new View(this);
        l2.setBackgroundColor(0x99C9A13B);
        TextView dot = new TextView(this);
        dot.setText("  ✦  ");
        dot.setTextColor(C_GOLD);
        dot.setTextSize(11);
        line.addView(l1, new LinearLayout.LayoutParams(dp(60), dp(1)));
        line.addView(dot);
        line.addView(l2, new LinearLayout.LayoutParams(dp(60), dp(1)));
        h.addView(line);

        TextView sub = new TextView(this);
        sub.setText("سامانه چاپ لیبل دم‌موشی طلا و جواهر");
        sub.setTextSize(13.5f);
        sub.setTextColor(0xFFE8DCC0);
        sub.setGravity(Gravity.CENTER);
        sub.setPadding(0, dp(6), 0, 0);
        h.addView(sub);
        return h;
    }

    private void buildUi() {
        ScrollView sv = new ScrollView(this);
        sv.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        sv.setBackgroundColor(C_BG);
        sv.setFillViewport(true);
        LinearLayout outer = vbox();
        sv.addView(outer);
        outer.addView(header());

        LinearLayout root = vbox();
        root.setPadding(dp(14), dp(2), dp(14), dp(28));
        outer.addView(root);

        // --- preview
        LinearLayout cPrev = card(root, "👁", "پیش‌نمایش");
        preview = new PreviewView(this);
        preview.setBackground(round(0xFFF4EFE3, 14, 0));
        preview.setClipToOutline(true);
        cPrev.addView(preview, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(150)));
        tvOffset = new TextView(this);
        tvOffset.setGravity(Gravity.CENTER);
        tvOffset.setTextSize(12.5f);
        tvOffset.setTextColor(C_BROWN);
        tvOffset.setBackground(round(0xFFFBF3DD, 10, 0));
        tvOffset.setPadding(dp(8), dp(6), dp(8), dp(6));
        cPrev.addView(tvOffset, matchWrap(8));

        // --- texts + print
        LinearLayout cText = card(root, "✎", "متن لیبل");
        note(cText, "هر سطر یک خط از لیبل است؛ اندازه متن خودکار تنظیم می‌شود.");
        etA = new EditText(this);
        etA.setHint("روی لیبل — مثلاً عیار و وزن");
        etA.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE);
        etA.setMinLines(2);
        etA.setGravity(Gravity.TOP | Gravity.START);
        styleInput(etA);
        etA.addTextChangedListener(watcher);
        cText.addView(etA, matchWrap(4));
        etB = new EditText(this);
        etB.setHint("پشت لیبل — مثلاً کد و اجرت");
        etB.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE);
        etB.setMinLines(2);
        etB.setGravity(Gravity.TOP | Gravity.START);
        styleInput(etB);
        etB.addTextChangedListener(watcher);
        cText.addView(etB, matchWrap(10));
        etCopies = numField(cText, "تعداد چاپ", "عدد");
        etCopies.setInputType(InputType.TYPE_CLASS_NUMBER);

        Button print = primary("🖨   چاپ لیبل", new View.OnClickListener() {
            public void onClick(View v) { doPrint(false); }
        });
        print.setTextSize(17);
        print.setMinHeight(dp(56));
        cText.addView(print, matchWrap(10));
        buttonRow(cText, 8, outline("📄  ذخیره PDF", new View.OnClickListener() {
            public void onClick(View v) { savePdf(); }
        }));

        // --- position
        LinearLayout cPos = card(root, "✥", "تنظیم محل چاپ");
        note(cPos, "کادر قرمز در پیش‌نمایش، محل دقیق چاپ است. گام جابجایی را انتخاب کنید:");

        RadioGroup rg = new RadioGroup(this);
        rg.setOrientation(RadioGroup.HORIZONTAL);
        rg.setGravity(Gravity.CENTER);
        final float[] steps = {0.1f, 0.25f, 0.5f, 1f};
        for (int i = 0; i < steps.length; i++) {
            RadioButton r = new RadioButton(this);
            r.setId(1000 + i);
            r.setText(LabelRenderer.fmt(steps[i]));
            r.setTextColor(C_TEXT);
            rg.addView(r);
            if (Math.abs(steps[i] - step) < 0.001f) r.setChecked(true);
        }
        rg.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            public void onCheckedChanged(RadioGroup g, int id) {
                int i = id - 1000;
                if (i >= 0 && i < steps.length) step = steps[i];
            }
        });
        cPos.addView(rg, matchWrap(0));

        LinearLayout pad = vbox();
        pad.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        pad.setGravity(Gravity.CENTER_HORIZONTAL);
        pad.setBackground(round(0xFFFBF7EC, 18, 0xFFEFE3C6));
        pad.setPadding(dp(8), dp(10), dp(8), dp(10));
        LinearLayout r1 = hbox(), r2 = hbox(), r3 = hbox();
        r1.setGravity(Gravity.CENTER);
        r2.setGravity(Gravity.CENTER);
        r3.setGravity(Gravity.CENTER);
        r1.addView(arrow("▲\nبالا", 0, -1));
        r2.addView(arrow("◀\nچپ", -1, 0));
        Button center = dark("●\nمرکز", new View.OnClickListener() {
            public void onClick(View v) { st.offsetX = 0; st.offsetY = 0; settingsToUi(); refresh(); }
        });
        r2.addView(center, arrowLp());
        r2.addView(arrow("▶\nراست", 1, 0));
        r3.addView(arrow("▼\nپایین", 0, 1));
        pad.addView(r1);
        pad.addView(r2);
        pad.addView(r3);
        cPos.addView(pad, matchWrap(8));

        etOffX = numField(cPos, "افقی X  (+ راست / − چپ)", "mm");
        etOffY = numField(cPos, "عمودی Y  (+ پایین / − بالا)", "mm");
        buttonRow(cPos, 8, dark("⊹  چاپ تست کالیبراسیون", new View.OnClickListener() {
            public void onClick(View v) { doPrint(true); }
        }));

        // --- size
        LinearLayout cSize = card(root, "📐", "اندازه لیبل");
        etW = numField(cSize, "عرض کل لیبل", "mm");
        etH = numField(cSize, "ارتفاع لیبل", "mm");
        etTail = numField(cSize, "طول دم", "mm");
        cbFold = check(cSize, "لیبل از وسط تا می‌شود (دو رو)");
        cbTail = check(cSize, "دم جزو صفحه چاپ است");
        cbTailLeft = check(cSize, "دم در سمت چپ لیبل است");

        // --- style
        LinearLayout cStyle = card(root, "Aa", "متن و چاپگر");
        etFont = numField(cStyle, "اندازه قلم", "mm");
        etPad = numField(cStyle, "فاصله متن از لبه", "mm");
        cbBold = check(cStyle, "قلم ضخیم");
        cbFa = check(cStyle, "اعداد فارسی (۱۲۳)");
        cbRotB = check(cStyle, "پشت لیبل ۱۸۰ درجه بچرخد");
        cbRotPage = check(cStyle, "صفحه ۹۰ درجه بچرخد (برای برخی چاپگرها)");
        cbBorder = check(cStyle, "چاپ کادر دور لیبل");

        // --- presets
        LinearLayout cSave = card(root, "💾", "ذخیره تنظیمات");
        buttonRow(cSave, 4,
                primary("ذخیره به‌عنوان پیش‌فرض", new View.OnClickListener() { public void onClick(View v) { saveDefault(); } }));
        buttonRow(cSave, 8,
                outline("بارگذاری پیش‌فرض", new View.OnClickListener() { public void onClick(View v) { loadDefault(); } }),
                outline("ذخیره با نام…", new View.OnClickListener() { public void onClick(View v) { savePresetDialog(); } }));
        buttonRow(cSave, 8,
                outline("تنظیمات ذخیره‌شده", new View.OnClickListener() { public void onClick(View v) { loadPresetDialog(); } }),
                outline("تنظیمات کارخانه", new View.OnClickListener() { public void onClick(View v) { factoryReset(); } }));

        TextView foot = new TextView(this);
        foot.setText("◆  گالری طلا روح‌اله انصاری  ◆");
        foot.setTextColor(C_MUTED);
        foot.setTextSize(12);
        foot.setGravity(Gravity.CENTER);
        root.addView(foot, matchWrap(22));

        setContentView(sv);
    }

    private LinearLayout.LayoutParams arrowLp() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(84), dp(64));
        lp.setMargins(dp(5), dp(4), dp(5), dp(4));
        return lp;
    }

    private Button arrow(String text, final int dx, final int dy) {
        Button b = primary(text, new View.OnClickListener() {
            public void onClick(View v) { move(dx, dy); }
        });
        b.setTextSize(13);
        b.setMinHeight(0);
        b.setPadding(0, dp(4), 0, dp(4));
        b.setLayoutParams(arrowLp());
        return b;
    }

    // ---------------------------------------------------------------- state sync

    private static float round2(float v) {
        return Math.round(v * 100f) / 100f;
    }

    private void move(int dx, int dy) {
        st.offsetX = round2(st.offsetX + dx * step);
        st.offsetY = round2(st.offsetY + dy * step);
        updating = true;
        etOffX.setText(LabelRenderer.fmt(st.offsetX));
        etOffY.setText(LabelRenderer.fmt(st.offsetY));
        updating = false;
        refresh();
    }

    private static float parse(EditText e, float def) {
        String s = e.getText().toString().trim();
        StringBuilder sb = new StringBuilder();
        for (char ch : s.toCharArray()) {
            if (ch >= '۰' && ch <= '۹') sb.append((char) ('0' + ch - '۰'));
            else if (ch >= '٠' && ch <= '٩') sb.append((char) ('0' + ch - '٠'));
            else if (ch == '٫' || ch == ',' || ch == '/') sb.append('.');
            else if (ch == '−') sb.append('-');
            else sb.append(ch);
        }
        try {
            return Float.parseFloat(sb.toString());
        } catch (Exception ex) {
            return def;
        }
    }

    private int copies() {
        int c = Math.round(parse(etCopies, 1));
        return Math.max(1, Math.min(500, c));
    }

    private void settingsToUi() {
        updating = true;
        etW.setText(LabelRenderer.fmt(st.labelWidth));
        etH.setText(LabelRenderer.fmt(st.labelHeight));
        etTail.setText(LabelRenderer.fmt(st.tailLength));
        etOffX.setText(LabelRenderer.fmt(st.offsetX));
        etOffY.setText(LabelRenderer.fmt(st.offsetY));
        etPad.setText(LabelRenderer.fmt(st.padding));
        etFont.setText(LabelRenderer.fmt(st.fontSize));
        cbFold.setChecked(st.fold);
        cbTail.setChecked(st.includeTail);
        cbTailLeft.setChecked(st.tailLeft);
        cbRotB.setChecked(st.rotateBack);
        cbRotPage.setChecked(st.rotatePage);
        cbBold.setChecked(st.bold);
        cbFa.setChecked(st.persianDigits);
        cbBorder.setChecked(st.printBorder);
        updating = false;
    }

    private void uiToSettings() {
        float w = parse(etW, st.labelWidth);
        float h = parse(etH, st.labelHeight);
        if (w > 1) st.labelWidth = w;
        if (h > 1) st.labelHeight = h;
        st.tailLength = Math.max(0, parse(etTail, st.tailLength));
        st.offsetX = parse(etOffX, st.offsetX);
        st.offsetY = parse(etOffY, st.offsetY);
        st.padding = Math.max(0, parse(etPad, st.padding));
        float f = parse(etFont, st.fontSize);
        if (f > 0.3f) st.fontSize = f;
        st.fold = cbFold.isChecked();
        st.includeTail = cbTail.isChecked();
        st.tailLeft = cbTailLeft.isChecked();
        st.rotateBack = cbRotB.isChecked();
        st.rotatePage = cbRotPage.isChecked();
        st.bold = cbBold.isChecked();
        st.persianDigits = cbFa.isChecked();
        st.printBorder = cbBorder.isChecked();
    }

    private void onUiChanged() {
        if (updating || etFont == null || cbBorder == null) return;
        uiToSettings();
        refresh();
    }

    private void refresh() {
        if (preview == null) return;
        preview.setData(st, etA.getText().toString(), etB.getText().toString());
        tvOffset.setText("X = " + LabelRenderer.fmt(st.offsetX) + " mm     Y = "
                + LabelRenderer.fmt(st.offsetY) + " mm     صفحه "
                + LabelRenderer.fmt(LabelRenderer.pageWidth(st)) + "×" + LabelRenderer.fmt(st.labelHeight));
    }

    // ---------------------------------------------------------------- print / pdf

    private void doPrint(boolean test) {
        uiToSettings();
        try {
            PrintManager pm = (PrintManager) getSystemService(Context.PRINT_SERVICE);
            LabelPrintAdapter ad = new LabelPrintAdapter(st.copy(), etA.getText().toString(),
                    etB.getText().toString(), test ? 1 : copies(), test);
            PrintAttributes attrs = new PrintAttributes.Builder()
                    .setMediaSize(LabelRenderer.mediaSize(st))
                    .setMinMargins(PrintAttributes.Margins.NO_MARGINS)
                    .setColorMode(PrintAttributes.COLOR_MODE_MONOCHROME)
                    .build();
            pm.print(test ? "GoldLabel-Test" : "GoldLabel", ad, attrs);
        } catch (Exception e) {
            toast("خطا در چاپ: " + e.getMessage());
        }
    }

    private void savePdf() {
        uiToSettings();
        Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("application/pdf");
        i.putExtra(Intent.EXTRA_TITLE, "gold_label.pdf");
        try {
            startActivityForResult(i, REQ_SAVE_PDF);
        } catch (Exception e) {
            toast("امکان ذخیره فایل وجود ندارد");
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQ_SAVE_PDF || resultCode != RESULT_OK || data == null) return;
        Uri uri = data.getData();
        if (uri == null) return;
        OutputStream os = null;
        try {
            os = getContentResolver().openOutputStream(uri);
            LabelRenderer.writePdf(os, st, etA.getText().toString(), etB.getText().toString(), copies(), false);
            toast("PDF ذخیره شد");
        } catch (Exception e) {
            toast("خطا: " + e.getMessage());
        } finally {
            if (os != null) {
                try { os.close(); } catch (Exception ignored) {}
            }
        }
    }

    // ---------------------------------------------------------------- presets

    private void toast(String m) {
        Toast.makeText(this, m, Toast.LENGTH_SHORT).show();
    }

    private void saveDefault() {
        uiToSettings();
        prefs.edit().putString(P_DEFAULT, st.toJson()).apply();
        toast("تنظیمات فعلی پیش‌فرض شد ✓");
    }

    private void loadDefault() {
        String def = prefs.getString(P_DEFAULT, null);
        if (def == null) { toast("هنوز پیش‌فرضی ذخیره نشده"); return; }
        st.applyJson(def);
        settingsToUi();
        refresh();
        toast("پیش‌فرض بارگذاری شد");
    }

    private void factoryReset() {
        new AlertDialog.Builder(this)
                .setMessage("تنظیمات به حالت کارخانه (۴۴×۱۰ و دم ۴۵ میلی‌متر) برگردد؟")
                .setPositiveButton("بله", (d, w) -> {
                    st.applyJson(new LabelSettings().toJson());
                    settingsToUi();
                    refresh();
                    toast("برای ماندگاری، «ذخیره به‌عنوان پیش‌فرض» را بزنید");
                })
                .setNegativeButton("خیر", null)
                .show();
    }

    private JSONObject presets() {
        try {
            return new JSONObject(prefs.getString(P_PRESETS, "{}"));
        } catch (Exception e) {
            return new JSONObject();
        }
    }

    private void savePresetDialog() {
        uiToSettings();
        LinearLayout box = vbox();
        box.setPadding(dp(20), dp(8), dp(20), 0);
        final EditText name = new EditText(this);
        name.setHint("نام (مثلاً چاپگر مغازه)");
        box.addView(name);
        final CheckBox asDef = new CheckBox(this);
        asDef.setText("پیش‌فرض هم بشود");
        box.addView(asDef);
        new AlertDialog.Builder(this)
                .setTitle("ذخیره تنظیمات")
                .setView(box)
                .setPositiveButton("ذخیره", (d, w) -> {
                    String n = name.getText().toString().trim();
                    if (n.isEmpty()) { toast("نام را وارد کنید"); return; }
                    try {
                        JSONObject p = presets();
                        p.put(n, st.toJson());
                        SharedPreferences.Editor ed = prefs.edit().putString(P_PRESETS, p.toString());
                        if (asDef.isChecked()) ed.putString(P_DEFAULT, st.toJson());
                        ed.apply();
                        toast("ذخیره شد ✓");
                    } catch (Exception e) {
                        toast("خطا در ذخیره");
                    }
                })
                .setNegativeButton("انصراف", null)
                .show();
    }

    private void loadPresetDialog() {
        final JSONObject p = presets();
        final List<String> names = new ArrayList<>();
        Iterator<String> it = p.keys();
        while (it.hasNext()) names.add(it.next());
        Collections.sort(names);
        if (names.isEmpty()) { toast("تنظیماتی ذخیره نشده"); return; }
        new AlertDialog.Builder(this)
                .setTitle("تنظیمات ذخیره‌شده")
                .setItems(names.toArray(new String[0]), (d, which) -> presetActions(p, names.get(which)))
                .setNegativeButton("بستن", null)
                .show();
    }

    private void presetActions(final JSONObject p, final String n) {
        String[] actions = {"بارگذاری", "بارگذاری و پیش‌فرض کردن", "حذف"};
        new AlertDialog.Builder(this)
                .setTitle(n)
                .setItems(actions, (d, which) -> {
                    String json = p.optString(n, null);
                    if (which == 2) {
                        p.remove(n);
                        prefs.edit().putString(P_PRESETS, p.toString()).apply();
                        toast("حذف شد");
                        return;
                    }
                    if (json == null) return;
                    st.applyJson(json);
                    settingsToUi();
                    refresh();
                    if (which == 1) prefs.edit().putString(P_DEFAULT, json).apply();
                    toast(which == 1 ? "بارگذاری و پیش‌فرض شد" : "بارگذاری شد");
                })
                .show();
    }
}
