package ir.goldlabel;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.print.PrintAttributes;
import android.print.PrintManager;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONObject;

import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

public class MainActivity extends Activity {
    private static final int REQ_SAVE_PDF = 11;
    private static final String P_DEFAULT = "default_settings";
    private static final String P_PRESETS = "presets";
    private static final String P_TEXT_A = "text_a";
    private static final String P_TEXT_B = "text_b";
    private static final String P_COPIES = "copies";
    private static final String P_STEP = "step";

    private SharedPreferences prefs;
    private final LabelSettings st = new LabelSettings();
    private boolean updating = false;
    private float step = 0.5f;

    private PreviewView preview;
    private EditText etA, etB, etCopies;
    private EditText etW, etH, etTail, etOffX, etOffY, etPad, etFont;
    private CheckBox cbFold, cbTail, cbTailLeft, cbRotB, cbRotPage, cbBold, cbFa, cbBorder;
    private TextView tvOffset;

    // ---------------------------------------------------------------- lifecycle

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences("gold_label", MODE_PRIVATE);
        String def = prefs.getString(P_DEFAULT, null);
        if (def != null) st.applyJson(def);
        step = prefs.getFloat(P_STEP, 0.5f);
        buildUi();
        settingsToUi();
        updating = true;
        etA.setText(prefs.getString(P_TEXT_A, "18 عیار\nوزن: 2.350"));
        etB.setText(prefs.getString(P_TEXT_B, "کد: 1024\nاجرت: 18%"));
        etCopies.setText(String.valueOf(prefs.getInt(P_COPIES, 1)));
        updating = false;
        refresh();
    }

    @Override
    protected void onPause() {
        super.onPause();
        prefs.edit()
                .putString(P_TEXT_A, etA.getText().toString())
                .putString(P_TEXT_B, etB.getText().toString())
                .putInt(P_COPIES, copies())
                .putFloat(P_STEP, step)
                .apply();
    }

    // ---------------------------------------------------------------- UI build

    private int dp(float v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    private LinearLayout vbox() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        return l;
    }

    private LinearLayout hbox() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.HORIZONTAL);
        l.setGravity(Gravity.CENTER_VERTICAL);
        return l;
    }

    private void section(LinearLayout root, String title) {
        TextView t = new TextView(this);
        t.setText(title);
        t.setTextSize(16);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setTextColor(0xFF6B4E0E);
        t.setPadding(0, dp(16), 0, dp(4));
        root.addView(t);
    }

    private final TextWatcher watcher = new TextWatcher() {
        public void beforeTextChanged(CharSequence s, int a, int b, int c) {}
        public void onTextChanged(CharSequence s, int a, int b, int c) {}
        public void afterTextChanged(Editable e) { onUiChanged(); }
    };

    private final CompoundButton.OnCheckedChangeListener checkListener =
            new CompoundButton.OnCheckedChangeListener() {
                public void onCheckedChanged(CompoundButton b, boolean v) { onUiChanged(); }
            };

    private EditText numField(LinearLayout parent, String label) {
        LinearLayout row = hbox();
        TextView tv = new TextView(this);
        tv.setText(label);
        tv.setTextSize(14);
        row.addView(tv, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1.4f));
        EditText e = new EditText(this);
        e.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL
                | InputType.TYPE_NUMBER_FLAG_SIGNED);
        e.setGravity(Gravity.CENTER);
        e.setSelectAllOnFocus(true);
        e.addTextChangedListener(watcher);
        row.addView(e, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        parent.addView(row);
        return e;
    }

    private CheckBox check(LinearLayout parent, String label) {
        CheckBox cb = new CheckBox(this);
        cb.setText(label);
        cb.setOnCheckedChangeListener(checkListener);
        parent.addView(cb);
        return cb;
    }

    private Button button(String text, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setOnClickListener(l);
        return b;
    }

    private void buttonRow(LinearLayout parent, Button... buttons) {
        LinearLayout row = hbox();
        for (Button b : buttons) {
            row.addView(b, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        }
        parent.addView(row);
    }

    private void buildUi() {
        ScrollView sv = new ScrollView(this);
        sv.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        sv.setBackgroundColor(0xFFFBF8F1);
        LinearLayout root = vbox();
        root.setPadding(dp(14), dp(8), dp(14), dp(24));
        sv.addView(root);

        // preview
        preview = new PreviewView(this);
        root.addView(preview, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(150)));
        tvOffset = new TextView(this);
        tvOffset.setGravity(Gravity.CENTER);
        tvOffset.setTextColor(0xFFD32F2F);
        root.addView(tvOffset);

        // texts
        section(root, "متن لیبل");
        etA = new EditText(this);
        etA.setHint("نیمه اول (روی لیبل) — هر سطر یک خط");
        etA.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE);
        etA.setMinLines(2);
        etA.addTextChangedListener(watcher);
        root.addView(etA);
        etB = new EditText(this);
        etB.setHint("نیمه دوم (پشت لیبل)");
        etB.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE);
        etB.setMinLines(2);
        etB.addTextChangedListener(watcher);
        root.addView(etB);
        etCopies = numField(root, "تعداد چاپ");
        etCopies.setInputType(InputType.TYPE_CLASS_NUMBER);

        buttonRow(root,
                button("🖨 چاپ", new View.OnClickListener() { public void onClick(View v) { doPrint(false); } }),
                button("ذخیره PDF", new View.OnClickListener() { public void onClick(View v) { savePdf(); } }));

        // position
        section(root, "محل چاپ (میلی‌متر)");
        TextView help = new TextView(this);
        help.setText("با فلش‌ها محل چاپ را جابه‌جا کنید. کادر قرمز = جایی که چاپ می‌شود.");
        help.setTextColor(0xFF666666);
        root.addView(help);

        RadioGroup rg = new RadioGroup(this);
        rg.setOrientation(RadioGroup.HORIZONTAL);
        rg.setGravity(Gravity.CENTER);
        final float[] steps = {0.1f, 0.25f, 0.5f, 1f};
        for (int i = 0; i < steps.length; i++) {
            RadioButton r = new RadioButton(this);
            r.setId(1000 + i);
            r.setText(LabelRenderer.fmt(steps[i]) + " mm");
            rg.addView(r);
            if (Math.abs(steps[i] - step) < 0.001f) r.setChecked(true);
        }
        rg.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            public void onCheckedChanged(RadioGroup g, int id) {
                int i = id - 1000;
                if (i >= 0 && i < steps.length) step = steps[i];
            }
        });
        root.addView(rg);

        LinearLayout pad = vbox();
        pad.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        pad.setGravity(Gravity.CENTER_HORIZONTAL);
        LinearLayout r1 = hbox(), r2 = hbox(), r3 = hbox();
        r1.addView(arrow("▲  بالا", 0, -1));
        r2.addView(arrow("◀ چپ", -1, 0));
        r2.addView(button("مرکز", new View.OnClickListener() {
            public void onClick(View v) { st.offsetX = 0; st.offsetY = 0; settingsToUi(); refresh(); }
        }));
        r2.addView(arrow("راست ▶", 1, 0));
        r3.addView(arrow("▼  پایین", 0, 1));
        pad.addView(r1);
        pad.addView(r2);
        pad.addView(r3);
        root.addView(pad, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT));

        etOffX = numField(root, "جابجایی افقی X (+ راست / − چپ)");
        etOffY = numField(root, "جابجایی عمودی Y (+ پایین / − بالا)");
        buttonRow(root,
                button("چاپ تست کالیبراسیون", new View.OnClickListener() { public void onClick(View v) { doPrint(true); } }));

        // label size
        section(root, "اندازه لیبل (میلی‌متر)");
        etW = numField(root, "عرض کل لیبل");
        etH = numField(root, "ارتفاع لیبل");
        etTail = numField(root, "طول دم");
        cbFold = check(root, "لیبل از وسط تا می‌شود (دو رو)");
        cbTail = check(root, "دم جزو صفحه چاپ است");
        cbTailLeft = check(root, "دم در سمت چپ لیبل است");

        // text style
        section(root, "متن و چاپ");
        etFont = numField(root, "اندازه قلم (میلی‌متر)");
        etPad = numField(root, "فاصله متن از لبه");
        cbBold = check(root, "قلم ضخیم (Bold)");
        cbFa = check(root, "اعداد فارسی");
        cbRotB = check(root, "نیمه دوم ۱۸۰ درجه بچرخد");
        cbRotPage = check(root, "صفحه ۹۰ درجه بچرخد (برای برخی چاپگرها)");
        cbBorder = check(root, "چاپ کادر دور لیبل");

        // presets
        section(root, "ذخیره تنظیمات");
        buttonRow(root,
                button("ذخیره به‌عنوان پیش‌فرض", new View.OnClickListener() { public void onClick(View v) { saveDefault(); } }),
                button("بارگذاری پیش‌فرض", new View.OnClickListener() { public void onClick(View v) { loadDefault(); } }));
        buttonRow(root,
                button("ذخیره با نام…", new View.OnClickListener() { public void onClick(View v) { savePresetDialog(); } }),
                button("تنظیمات ذخیره‌شده", new View.OnClickListener() { public void onClick(View v) { loadPresetDialog(); } }));
        buttonRow(root,
                button("بازگشت به تنظیمات کارخانه", new View.OnClickListener() { public void onClick(View v) { factoryReset(); } }));

        setContentView(sv);
    }

    private Button arrow(String text, final int dx, final int dy) {
        Button b = button(text, new View.OnClickListener() {
            public void onClick(View v) { move(dx, dy); }
        });
        b.setMinWidth(dp(96));
        return b;
    }

    // ---------------------------------------------------------------- state sync

    private static float round2(float v) {
        return Math.round(v * 100f) / 100f;
    }

    private void move(int dx, int dy) {
        st.offsetX = round2(st.offsetX + dx * step);
        st.offsetY = round2(st.offsetY + dy * step);
        updating = true;
        etOffX.setText(LabelRenderer.fmt(st.offsetX));
        etOffY.setText(LabelRenderer.fmt(st.offsetY));
        updating = false;
        refresh();
    }

    private static float parse(EditText e, float def) {
        String s = e.getText().toString().trim();
        StringBuilder sb = new StringBuilder();
        for (char ch : s.toCharArray()) {
            if (ch >= '۰' && ch <= '۹') sb.append((char) ('0' + ch - '۰'));
            else if (ch >= '٠' && ch <= '٩') sb.append((char) ('0' + ch - '٠'));
            else if (ch == '٫' || ch == ',' || ch == '/') sb.append('.');
            else if (ch == '−') sb.append('-');
            else sb.append(ch);
        }
        try {
            return Float.parseFloat(sb.toString());
        } catch (Exception ex) {
            return def;
        }
    }

    private int copies() {
        int c = Math.round(parse(etCopies, 1));
        return Math.max(1, Math.min(500, c));
    }

    private void settingsToUi() {
        updating = true;
        etW.setText(LabelRenderer.fmt(st.labelWidth));
        etH.setText(LabelRenderer.fmt(st.labelHeight));
        etTail.setText(LabelRenderer.fmt(st.tailLength));
        etOffX.setText(LabelRenderer.fmt(st.offsetX));
        etOffY.setText(LabelRenderer.fmt(st.offsetY));
        etPad.setText(LabelRenderer.fmt(st.padding));
        etFont.setText(LabelRenderer.fmt(st.fontSize));
        cbFold.setChecked(st.fold);
        cbTail.setChecked(st.includeTail);
        cbTailLeft.setChecked(st.tailLeft);
        cbRotB.setChecked(st.rotateBack);
        cbRotPage.setChecked(st.rotatePage);
        cbBold.setChecked(st.bold);
        cbFa.setChecked(st.persianDigits);
        cbBorder.setChecked(st.printBorder);
        updating = false;
    }

    private void uiToSettings() {
        float w = parse(etW, st.labelWidth);
        float h = parse(etH, st.labelHeight);
        if (w > 1) st.labelWidth = w;
        if (h > 1) st.labelHeight = h;
        st.tailLength = Math.max(0, parse(etTail, st.tailLength));
        st.offsetX = parse(etOffX, st.offsetX);
        st.offsetY = parse(etOffY, st.offsetY);
        st.padding = Math.max(0, parse(etPad, st.padding));
        float f = parse(etFont, st.fontSize);
        if (f > 0.3f) st.fontSize = f;
        st.fold = cbFold.isChecked();
        st.includeTail = cbTail.isChecked();
        st.tailLeft = cbTailLeft.isChecked();
        st.rotateBack = cbRotB.isChecked();
        st.rotatePage = cbRotPage.isChecked();
        st.bold = cbBold.isChecked();
        st.persianDigits = cbFa.isChecked();
        st.printBorder = cbBorder.isChecked();
    }

    private void onUiChanged() {
        if (updating || etFont == null || cbBorder == null) return;
        uiToSettings();
        refresh();
    }

    private void refresh() {
        if (preview == null) return;
        preview.setData(st, etA.getText().toString(), etB.getText().toString());
        tvOffset.setText("جابجایی:  X = " + LabelRenderer.fmt(st.offsetX) + " mm    Y = "
                + LabelRenderer.fmt(st.offsetY) + " mm    صفحه: "
                + LabelRenderer.fmt(LabelRenderer.pageWidth(st)) + "×" + LabelRenderer.fmt(st.labelHeight));
    }

    // ---------------------------------------------------------------- print / pdf

    private void doPrint(boolean test) {
        uiToSettings();
        try {
            PrintManager pm = (PrintManager) getSystemService(Context.PRINT_SERVICE);
            LabelPrintAdapter ad = new LabelPrintAdapter(st.copy(), etA.getText().toString(),
                    etB.getText().toString(), test ? 1 : copies(), test);
            PrintAttributes attrs = new PrintAttributes.Builder()
                    .setMediaSize(LabelRenderer.mediaSize(st))
                    .setMinMargins(PrintAttributes.Margins.NO_MARGINS)
                    .setColorMode(PrintAttributes.COLOR_MODE_MONOCHROME)
                    .build();
            pm.print(test ? "GoldLabel-Test" : "GoldLabel", ad, attrs);
        } catch (Exception e) {
            toast("خطا در چاپ: " + e.getMessage());
        }
    }

    private void savePdf() {
        uiToSettings();
        Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("application/pdf");
        i.putExtra(Intent.EXTRA_TITLE, "gold_label.pdf");
        try {
            startActivityForResult(i, REQ_SAVE_PDF);
        } catch (Exception e) {
            toast("امکان ذخیره فایل وجود ندارد");
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQ_SAVE_PDF || resultCode != RESULT_OK || data == null) return;
        Uri uri = data.getData();
        if (uri == null) return;
        OutputStream os = null;
        try {
            os = getContentResolver().openOutputStream(uri);
            LabelRenderer.writePdf(os, st, etA.getText().toString(), etB.getText().toString(), copies(), false);
            toast("PDF ذخیره شد");
        } catch (Exception e) {
            toast("خطا: " + e.getMessage());
        } finally {
            if (os != null) {
                try { os.close(); } catch (Exception ignored) {}
            }
        }
    }

    // ---------------------------------------------------------------- presets

    private void toast(String m) {
        Toast.makeText(this, m, Toast.LENGTH_SHORT).show();
    }

    private void saveDefault() {
        uiToSettings();
        prefs.edit().putString(P_DEFAULT, st.toJson()).apply();
        toast("تنظیمات فعلی پیش‌فرض شد");
    }

    private void loadDefault() {
        String def = prefs.getString(P_DEFAULT, null);
        if (def == null) { toast("هنوز پیش‌فرضی ذخیره نشده"); return; }
        st.applyJson(def);
        settingsToUi();
        refresh();
        toast("پیش‌فرض بارگذاری شد");
    }

    private void factoryReset() {
        new AlertDialog.Builder(this)
                .setMessage("تنظیمات به حالت کارخانه (۴۴×۱۰ و دم ۴۵ میلی‌متر) برگردد؟")
                .setPositiveButton("بله", (d, w) -> {
                    st.applyJson(new LabelSettings().toJson());
                    settingsToUi();
                    refresh();
                    toast("برای ماندگاری، «ذخیره به‌عنوان پیش‌فرض» را بزنید");
                })
                .setNegativeButton("خیر", null)
                .show();
    }

    private JSONObject presets() {
        try {
            return new JSONObject(prefs.getString(P_PRESETS, "{}"));
        } catch (Exception e) {
            return new JSONObject();
        }
    }

    private void savePresetDialog() {
        uiToSettings();
        LinearLayout box = vbox();
        box.setPadding(dp(20), dp(8), dp(20), 0);
        final EditText name = new EditText(this);
        name.setHint("نام (مثلاً چاپگر مغازه)");
        box.addView(name);
        final CheckBox asDef = new CheckBox(this);
        asDef.setText("پیش‌فرض هم بشود");
        box.addView(asDef);
        new AlertDialog.Builder(this)
                .setTitle("ذخیره تنظیمات")
                .setView(box)
                .setPositiveButton("ذخیره", (d, w) -> {
                    String n = name.getText().toString().trim();
                    if (n.isEmpty()) { toast("نام را وارد کنید"); return; }
                    try {
                        JSONObject p = presets();
                        p.put(n, st.toJson());
                        SharedPreferences.Editor ed = prefs.edit().putString(P_PRESETS, p.toString());
                        if (asDef.isChecked()) ed.putString(P_DEFAULT, st.toJson());
                        ed.apply();
                        toast("ذخیره شد");
                    } catch (Exception e) {
                        toast("خطا در ذخیره");
                    }
                })
                .setNegativeButton("انصراف", null)
                .show();
    }

    private void loadPresetDialog() {
        final JSONObject p = presets();
        final List<String> names = new ArrayList<>();
        Iterator<String> it = p.keys();
        while (it.hasNext()) names.add(it.next());
        Collections.sort(names);
        if (names.isEmpty()) { toast("تنظیماتی ذخیره نشده"); return; }
        new AlertDialog.Builder(this)
                .setTitle("تنظیمات ذخیره‌شده")
                .setItems(names.toArray(new String[0]), (d, which) -> presetActions(p, names.get(which)))
                .setNegativeButton("بستن", null)
                .show();
    }

    private void presetActions(final JSONObject p, final String n) {
        String[] actions = {"بارگذاری", "بارگذاری و پیش‌فرض کردن", "حذف"};
        new AlertDialog.Builder(this)
                .setTitle(n)
                .setItems(actions, (d, which) -> {
                    String json = p.optString(n, null);
                    if (which == 2) {
                        p.remove(n);
                        prefs.edit().putString(P_PRESETS, p.toString()).apply();
                        toast("حذف شد");
                        return;
                    }
                    if (json == null) return;
                    st.applyJson(json);
                    settingsToUi();
                    refresh();
                    if (which == 1) prefs.edit().putString(P_DEFAULT, json).apply();
                    toast(which == 1 ? "بارگذاری و پیش‌فرض شد" : "بارگذاری شد");
                })
                .show();
    }
}
