package ir.goldlabel;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.ColorStateList;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.hardware.usb.UsbDevice;
import android.os.Bundle;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

public class MainActivity extends Activity {
    private static final String P_DEFAULT = "default_settings";
    private static final String P_DEFAULT_NAME = "default_name";
    private static final String P_PRESETS = "presets";
    private static final String P_PROFILE_NAME = "profile_name";
    private static final String P_STEP = "step";
    private static final String P_WEIGHT = "q_weight";
    private static final String P_WAGE = "q_wage";
    private static final String P_KARAT = "q_karat";
    private static final String P_CODE = "q_code";
    private static final String P_PREFIX = "q_prefix";

    // palette
    private static final int C_DARK = 0xFF2B1D0E;
    private static final int C_BROWN = 0xFF5A3E12;
    private static final int C_GOLD = 0xFFC9A13B;
    private static final int C_GOLD_LIGHT = 0xFFF1D78A;
    private static final int C_GOLD_DEEP = 0xFFA97C14;
    private static final int C_BG = 0xFFF6F1E6;
    private static final int C_CARD_STROKE = 0xFFE8DCBE;
    private static final int C_TEXT = 0xFF33270F;
    private static final int C_MUTED = 0xFF8A7B5C;

    private SharedPreferences prefs;
    private final LabelSettings st = new LabelSettings();
    private boolean updating = false;
    private boolean printing = false;
    private float step = 0.5f;
    private String profileName = "پیش‌فرض";

    private UsbPrinter usb;
    private PreviewView preview;
    private ScrollView scroll;
    private LinearLayout settingsBox;
    private Button settingsToggle;
    private TextView tvOffset, tvUsb, tvProfile;

    // quick fields
    private EditText etPrefix, etCode, etWeight, etWage, etKarat;
    // settings fields
    private EditText etTplA, etTplB, etCodeStep;
    private EditText etW, etH, etTail, etOffX, etOffY, etPad, etFont, etGap, etDensity;
    private CheckBox cbFold, cbTail, cbTailLeft, cbRotB, cbRotPage, cbBold, cbFa, cbBorder, cbFlip;
    private CheckBox cbClearWeight, cbClearWage;
    private android.widget.Spinner spTypeA, spTypeB, spAlignA, spAlignB;
    private EditText etQrTpl, etBarTpl, etF1Name, etF2Name, etF1, etF2;
    private RadioGroup rgLang, rgDpi, rgConn;
    private EditText etHost, etPort;
    private TextView tvBt;

    // ================================================================= lifecycle

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(C_DARK);
        getWindow().setNavigationBarColor(C_DARK);
        prefs = getSharedPreferences("gold_label", MODE_PRIVATE);
        usb = new UsbPrinter(this);
        String def = prefs.getString(P_DEFAULT, null);
        if (def != null) st.applyJson(def);
        profileName = prefs.getString(P_PROFILE_NAME, prefs.getString(P_DEFAULT_NAME, "پیش‌فرض"));
        step = prefs.getFloat(P_STEP, 0.5f);
        seedProfiles();

        buildUi();
        settingsToUi();
        updating = true;
        etPrefix.setText(prefs.getString(P_PREFIX, st.codePrefix));
        etCode.setText(prefs.getString(P_CODE, "1001"));
        etKarat.setText(prefs.getString(P_KARAT, "18"));
        etWage.setText(prefs.getString(P_WAGE, ""));
        etWeight.setText(prefs.getString(P_WEIGHT, ""));
        updating = false;
        refresh();
    }

    /** First run: create two ready profiles, «عادی» and «QR». */
    private void seedProfiles() {
        if (prefs.getBoolean("seeded_qr", false)) return;
        try {
            JSONObject p = presets();
            LabelSettings normal = st.copy();
            LabelSettings qr = st.copy();
            qr.typeA = LabelSettings.T_TEXT;
            qr.typeB = LabelSettings.T_QR;
            qr.tplA = "{کد}\nاجرت: {اجرت}%\nوزن: {وزن}";
            if (!p.has("عادی")) p.put("عادی", normal.toJson());
            if (!p.has("QR")) p.put("QR", qr.toJson());
            prefs.edit().putString(P_PRESETS, p.toString()).putBoolean("seeded_qr", true).apply();
        } catch (Exception ignored) {
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        updateUsbStatus();
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        updateUsbStatus();
    }

    @Override
    protected void onPause() {
        super.onPause();
        saveQuickState();
    }

    private void saveQuickState() {
        prefs.edit()
                .putString(P_PREFIX, etPrefix.getText().toString())
                .putString(P_CODE, etCode.getText().toString())
                .putString(P_KARAT, etKarat.getText().toString())
                .putString(P_WAGE, etWage.getText().toString())
                .putString(P_WEIGHT, etWeight.getText().toString())
                .putString(P_PROFILE_NAME, profileName)
                .putFloat(P_STEP, step)
                .apply();
    }

    // ================================================================= styling helpers

    private int dp(float v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    private GradientDrawable round(int color, float radiusDp, int stroke) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(radiusDp));
        if (stroke != 0) g.setStroke(dp(1), stroke);
        return g;
    }

    private Drawable ripple(Drawable content, int rippleColor) {
        return new RippleDrawable(ColorStateList.valueOf(rippleColor), content, null);
    }

    private LinearLayout vbox() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        return l;
    }

    private LinearLayout hbox() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.HORIZONTAL);
        l.setGravity(Gravity.CENTER_VERTICAL);
        return l;
    }

    private LinearLayout.LayoutParams matchWrap(int topMarginDp) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.topMargin = dp(topMarginDp);
        return lp;
    }

    private LinearLayout card(LinearLayout parent, String icon, String title) {
        LinearLayout c = vbox();
        c.setBackground(round(0xFFFFFFFF, 18, C_CARD_STROKE));
        c.setElevation(dp(3));
        c.setPadding(dp(16), dp(14), dp(16), dp(16));

        LinearLayout head = hbox();
        View bar = new View(this);
        bar.setBackground(round(C_GOLD, 3, 0));
        head.addView(bar, new LinearLayout.LayoutParams(dp(5), dp(22)));
        TextView t = new TextView(this);
        t.setText(icon + "  " + title);
        t.setTextSize(16.5f);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setTextColor(C_TEXT);
        t.setPadding(dp(10), 0, dp(10), 0);
        head.addView(t);
        c.addView(head);

        View div = new View(this);
        div.setBackgroundColor(0xFFF0E7D2);
        LinearLayout.LayoutParams dl = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(1));
        dl.topMargin = dp(10);
        dl.bottomMargin = dp(6);
        c.addView(div, dl);

        parent.addView(c, matchWrap(14));
        return c;
    }

    private TextView note(LinearLayout parent, String text) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextSize(12.5f);
        t.setTextColor(C_MUTED);
        t.setPadding(0, dp(2), 0, dp(6));
        parent.addView(t);
        return t;
    }

    private TextView label(LinearLayout parent, String text) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextColor(C_TEXT);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setPadding(0, dp(10), 0, dp(2));
        parent.addView(t);
        return t;
    }

    private void styleInput(EditText e) {
        e.setBackground(round(0xFFFBF8F1, 12, 0xFFE3D5B0));
        e.setPadding(dp(12), dp(10), dp(12), dp(10));
        e.setTextColor(C_TEXT);
        e.setHintTextColor(0xFFB5A887);
        e.setTextSize(15);
    }

    private final TextWatcher watcher = new TextWatcher() {
        public void beforeTextChanged(CharSequence s, int a, int b, int c) {}
        public void onTextChanged(CharSequence s, int a, int b, int c) {}
        public void afterTextChanged(Editable e) { onUiChanged(); }
    };

    private final CompoundButton.OnCheckedChangeListener checkListener =
            new CompoundButton.OnCheckedChangeListener() {
                public void onCheckedChanged(CompoundButton b, boolean v) { onUiChanged(); }
            };

    private static final int NUM = InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL
            | InputType.TYPE_NUMBER_FLAG_SIGNED;

    private EditText numField(LinearLayout parent, String label, String unit) {
        LinearLayout row = hbox();
        row.setPadding(0, dp(5), 0, dp(5));
        TextView tv = new TextView(this);
        tv.setText(label);
        tv.setTextSize(14);
        tv.setTextColor(C_TEXT);
        row.addView(tv, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1.5f));
        EditText e = new EditText(this);
        e.setInputType(NUM);
        e.setGravity(Gravity.CENTER);
        e.setSelectAllOnFocus(true);
        styleInput(e);
        e.setTypeface(Typeface.DEFAULT_BOLD);
        e.addTextChangedListener(watcher);
        row.addView(e, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        TextView u = new TextView(this);
        u.setText(unit == null ? "" : unit);
        u.setTextSize(12);
        u.setTextColor(C_MUTED);
        u.setPadding(dp(6), 0, 0, 0);
        row.addView(u, new LinearLayout.LayoutParams(dp(34), ViewGroup.LayoutParams.WRAP_CONTENT));
        parent.addView(row);
        return e;
    }

    /** Large field for the quick-entry card. */
    private EditText bigField(LinearLayout parent, String label, String unit, String hint) {
        EditText e = numField(parent, label, unit);
        e.setTextSize(22);
        e.setHint(hint);
        e.setSelectAllOnFocus(true);
        e.setPadding(dp(12), dp(12), dp(12), dp(12));
        return e;
    }

    private CheckBox check(LinearLayout parent, String label) {
        CheckBox cb = new CheckBox(this);
        cb.setText(label);
        cb.setTextSize(14);
        cb.setTextColor(C_TEXT);
        cb.setPadding(dp(4), dp(6), dp(4), dp(6));
        cb.setOnCheckedChangeListener(checkListener);
        parent.addView(cb);
        return cb;
    }

    private Button baseButton(String text, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setTextSize(14.5f);
        b.setStateListAnimator(null);
        b.setMinHeight(dp(48));
        b.setPadding(dp(10), dp(8), dp(10), dp(8));
        b.setOnClickListener(l);
        return b;
    }

    private Button primary(String text, View.OnClickListener l) {
        Button b = baseButton(text, l);
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{C_GOLD_LIGHT, C_GOLD, C_GOLD_DEEP});
        g.setCornerRadius(dp(14));
        b.setBackground(ripple(g, 0x55FFFFFF));
        b.setTextColor(C_DARK);
        b.setTypeface(Typeface.DEFAULT_BOLD);
        b.setElevation(dp(3));
        return b;
    }

    private Button dark(String text, View.OnClickListener l) {
        Button b = baseButton(text, l);
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{C_BROWN, C_DARK});
        g.setCornerRadius(dp(14));
        b.setBackground(ripple(g, 0x44F1D78A));
        b.setTextColor(C_GOLD_LIGHT);
        b.setTypeface(Typeface.DEFAULT_BOLD);
        return b;
    }

    private Button outline(String text, View.OnClickListener l) {
        Button b = baseButton(text, l);
        b.setBackground(ripple(round(0xFFFFFCF5, 14, C_GOLD), 0x33C9A13B));
        b.setTextColor(C_BROWN);
        return b;
    }

    private void buttonRow(LinearLayout parent, int topDp, Button... buttons) {
        LinearLayout row = hbox();
        for (int i = 0; i < buttons.length; i++) {
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
            if (i > 0) lp.setMarginStart(dp(8));
            row.addView(buttons[i], lp);
        }
        parent.addView(row, matchWrap(topDp));
    }

    private View.OnClickListener click(final Runnable r) {
        return new View.OnClickListener() { public void onClick(View v) { r.run(); } };
    }

    // ================================================================= UI build

    private View header() {
        LinearLayout h = vbox();
        h.setGravity(Gravity.CENTER_HORIZONTAL);
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{C_DARK, C_BROWN, 0xFF7A5A1C});
        float r = dp(26);
        g.setCornerRadii(new float[]{0, 0, 0, 0, r, r, r, r});
        h.setBackground(g);
        h.setPadding(dp(20), dp(16), dp(20), dp(18));
        h.setElevation(dp(6));

        TextView t = new TextView(this);
        t.setText("◆  گالری طلا روح‌اله انصاری  ◆");
        t.setTextSize(21);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setTextColor(C_GOLD_LIGHT);
        t.setGravity(Gravity.CENTER);
        t.setShadowLayer(dp(4), 0, dp(1), 0x66000000);
        h.addView(t);

        TextView sub = new TextView(this);
        sub.setText("چاپ سریع لیبل دم‌موشی طلا و جواهر");
        sub.setTextSize(13);
        sub.setTextColor(0xFFE8DCC0);
        sub.setGravity(Gravity.CENTER);
        sub.setPadding(0, dp(4), 0, 0);
        h.addView(sub);

        tvUsb = new TextView(this);
        tvUsb.setTextSize(12.5f);
        tvUsb.setGravity(Gravity.CENTER);
        tvUsb.setPadding(dp(10), dp(5), dp(10), dp(5));
        tvUsb.setBackground(round(0x33000000, 12, 0));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.topMargin = dp(10);
        h.addView(tvUsb, lp);
        tvUsb.setOnClickListener(click(new Runnable() { public void run() { updateUsbStatus(); } }));
        return h;
    }

    private void buildUi() {
        scroll = new ScrollView(this);
        scroll.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        scroll.setBackgroundColor(C_BG);
        scroll.setFillViewport(true);
        LinearLayout outer = vbox();
        scroll.addView(outer);
        outer.addView(header());

        LinearLayout root = vbox();
        root.setPadding(dp(14), dp(0), dp(14), dp(28));
        outer.addView(root);

        // ---------------- preview
        LinearLayout cPrev = card(root, "👁", "پیش‌نمایش");
        preview = new PreviewView(this);
        preview.setBackground(round(0xFFF4EFE3, 14, 0));
        preview.setClipToOutline(true);
        cPrev.addView(preview, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(130)));

        // ---------------- quick entry
        LinearLayout cQ = card(root, "⚡", "ورود سریع");
        tvProfile = new TextView(this);
        tvProfile.setTextSize(13);
        tvProfile.setTextColor(C_BROWN);
        tvProfile.setBackground(ripple(round(0xFFFBF3DD, 10, 0), 0x33C9A13B));
        tvProfile.setPadding(dp(10), dp(7), dp(10), dp(7));
        tvProfile.setOnClickListener(click(new Runnable() { public void run() { loadPresetDialog(); } }));
        cQ.addView(tvProfile, matchWrap(0));

        // code row: [label] [N-|1012] [+] [−]
        LinearLayout codeRow = hbox();
        codeRow.setPadding(0, dp(8), 0, dp(4));
        TextView cl = new TextView(this);
        cl.setText("کد کالا");
        cl.setTextSize(14);
        cl.setTextColor(C_TEXT);
        codeRow.addView(cl, new LinearLayout.LayoutParams(dp(62), ViewGroup.LayoutParams.WRAP_CONTENT));
        LinearLayout codeBox = hbox();
        codeBox.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        codeBox.setBackground(round(0xFFFBF8F1, 12, 0xFFE3D5B0));
        etPrefix = new EditText(this);
        etPrefix.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS);
        etPrefix.setBackground(null);
        etPrefix.setTextSize(20);
        etPrefix.setTextColor(C_MUTED);
        etPrefix.setGravity(Gravity.CENTER);
        etPrefix.setPadding(dp(8), dp(10), 0, dp(10));
        etPrefix.addTextChangedListener(watcher);
        codeBox.addView(etPrefix, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT));
        etCode = new EditText(this);
        etCode.setInputType(InputType.TYPE_CLASS_NUMBER);
        etCode.setBackground(null);
        etCode.setTextSize(22);
        etCode.setTypeface(Typeface.DEFAULT_BOLD);
        etCode.setTextColor(C_TEXT);
        etCode.setPadding(0, dp(10), dp(8), dp(10));
        etCode.setSelectAllOnFocus(true);
        etCode.addTextChangedListener(watcher);
        codeBox.addView(etCode, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        codeRow.addView(codeBox, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        Button plus = outline("+", click(new Runnable() { public void run() { bumpCode(1); } }));
        Button minus = outline("−", click(new Runnable() { public void run() { bumpCode(-1); } }));
        plus.setTextSize(20);
        minus.setTextSize(20);
        LinearLayout.LayoutParams pl = new LinearLayout.LayoutParams(dp(48), dp(52));
        pl.setMarginStart(dp(6));
        codeRow.addView(plus, pl);
        LinearLayout.LayoutParams ml = new LinearLayout.LayoutParams(dp(48), dp(52));
        ml.setMarginStart(dp(6));
        codeRow.addView(minus, ml);
        cQ.addView(codeRow);

        etKarat = bigField(cQ, "عیار", "", "18");
        etWeight = bigField(cQ, "وزن", "گرم", "0.000");
        etWage = bigField(cQ, "اجرت", "%", "مثلاً 7");
        etF1 = bigField(cQ, "فیلد ۱", "", "");
        etF2 = bigField(cQ, "فیلد ۲", "", "");
        etF1.setInputType(InputType.TYPE_CLASS_TEXT);
        etF2.setInputType(InputType.TYPE_CLASS_TEXT);
        etF1.addTextChangedListener(watcher);
        etF2.addTextChangedListener(watcher);
        etF1.setImeOptions(EditorInfo.IME_ACTION_NEXT);
        etF2.setImeOptions(EditorInfo.IME_ACTION_NEXT);
        etWeight.setImeOptions(EditorInfo.IME_ACTION_NEXT);
        etWage.setImeOptions(EditorInfo.IME_ACTION_NEXT);
        etKarat.setImeOptions(EditorInfo.IME_ACTION_DONE);
        TextView.OnEditorActionListener printOnDone = new TextView.OnEditorActionListener() {
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                if (actionId == EditorInfo.IME_ACTION_DONE) { usbPrint(false); return true; }
                return false;
            }
        };
        etWage.setOnEditorActionListener(printOnDone);
        etWeight.setOnEditorActionListener(printOnDone);
        etKarat.setOnEditorActionListener(printOnDone);
        etF1.setOnEditorActionListener(printOnDone);
        etF2.setOnEditorActionListener(printOnDone);

        Button print = primary("🖨   چاپ", click(new Runnable() { public void run() { usbPrint(false); } }));
        print.setTextSize(20);
        print.setMinHeight(dp(62));
        cQ.addView(print, matchWrap(12));
        Button scanBtn = dark("📷   اسکن QR و ثبت کالاها", click(new Runnable() {
            public void run() { startActivity(new Intent(MainActivity.this, ScanActivity.class)); }
        }));
        cQ.addView(scanBtn, matchWrap(8));
        note(cQ, "وزن را بزنید ← «بعدی» ← اجرت ← «تأیید» تا چاپ شود. بعد از هر چاپ، کد خودکار یکی جلو می‌رود.");

        // ---------------- settings toggle
        settingsToggle = outline("⚙   تنظیمات و پروفایل  ▾", click(new Runnable() {
            public void run() { toggleSettings(); }
        }));
        root.addView(settingsToggle, matchWrap(16));

        settingsBox = vbox();
        settingsBox.setVisibility(View.GONE);
        root.addView(settingsBox, matchWrap(0));
        buildSettings(settingsBox);

        TextView foot = new TextView(this);
        foot.setText("◆  گالری طلا روح‌اله انصاری  ◆");
        foot.setTextColor(C_MUTED);
        foot.setTextSize(12);
        foot.setGravity(Gravity.CENTER);
        root.addView(foot, matchWrap(22));

        setContentView(scroll);
    }

    private void toggleSettings() {
        boolean show = settingsBox.getVisibility() != View.VISIBLE;
        settingsBox.setVisibility(show ? View.VISIBLE : View.GONE);
        settingsToggle.setText(show ? "⚙   بستن تنظیمات  ▴" : "⚙   تنظیمات و پروفایل  ▾");
    }

    private void buildSettings(LinearLayout root) {
        // ---------------- profiles
        LinearLayout cSave = card(root, "👤", "پروفایل‌ها");
        note(cSave, "پروفایل همه‌چیز را نگه می‌دارد: قالب متن، پیشوند کد، اندازه لیبل، محل چاپ و تنظیمات چاپگر. پروفایل پیش‌فرض هنگام باز شدن برنامه خودکار بارگذاری می‌شود.");
        buttonRow(cSave, 4, primary("💾  ذخیره پروفایل", click(new Runnable() { public void run() { savePresetDialog(); } })));
        buttonRow(cSave, 8,
                outline("📂  پروفایل‌ها", click(new Runnable() { public void run() { loadPresetDialog(); } })),
                outline("تنظیمات کارخانه", click(new Runnable() { public void run() { factoryReset(); } })));
        label(cSave, "پشتیبان‌گیری و انتقال");
        buttonRow(cSave, 2,
                dark("📤  خروجی پروفایل‌ها", click(new Runnable() { public void run() { exportProfiles(); } })),
                dark("📥  بارگذاری از فایل", click(new Runnable() { public void run() { importProfiles(); } })));
        buttonRow(cSave, 8,
                outline("📨  ارسال فایل پروفایل‌ها (ایتا، تلگرام…)", click(new Runnable() { public void run() { shareProfiles(); } })));
        note(cSave, "از همه پروفایل‌ها یک فایل پشتیبان (gold_profiles.json) ساخته می‌شود. با «بارگذاری از فایل» روی همین گوشی یا گوشی دیگر برمی‌گردند.");

        // ---------------- template designer
        LinearLayout cTpl = card(root, "🎨", "طراحی قالب لیبل");
        buttonRow(cTpl, 0, primary("📋  قالب‌های آماده", click(new Runnable() { public void run() { templatePresets(); } })));
        note(cTpl, "مقدارها با این کلمه‌ها جایگذاری می‌شوند:\n{کد}  {شماره}  {وزن}  {اجرت}  {عیار}  {تاریخ}  {فیلد۱}  {فیلد۲}\n"
                + "• هر سطر = یک خط لیبل؛ هر تعداد سطر که بخواهید (اندازه خودکار تنظیم می‌شود).\n"
                + "• سطری که با # شروع شود، درشت و پررنگ چاپ می‌شود.\n"
                + "• سطری که مقدارش خالی باشد چاپ نمی‌شود.\n"
                + "• فقط فیلدهایی که در قالب به کار رفته‌اند در صفحه اصلی نمایش داده می‌شوند.");

        String[] types = {"متن", "QR کد", "بارکد", "QR + متن کنارش", "بارکد + متن زیرش"};
        String[] aligns = {"وسط‌چین", "راست‌چین", "چپ‌چین"};
        label(cTpl, "◧  نیمه اول (روی لیبل)");
        spTypeA = spinner(cTpl, "نوع:", types);
        spAlignA = spinner(cTpl, "چینش متن:", aligns);
        etTplA = templateBox(cTpl);
        label(cTpl, "◨  نیمه دوم (پشت لیبل)");
        spTypeB = spinner(cTpl, "نوع:", types);
        spAlignB = spinner(cTpl, "چینش متن:", aligns);
        etTplB = templateBox(cTpl);

        label(cTpl, "محتوای QR کد");
        etQrTpl = templateBox(cTpl);
        etQrTpl.setMinLines(1);
        note(cTpl, "پیش‌فرض {کد}/{وزن}/{اجرت}/{عیار} است و اسکنر برنامه آن را کامل می‌خواند. محتوای کوتاه‌تر = QR درشت‌تر و خواناتر.");
        label(cTpl, "محتوای بارکد");
        etBarTpl = templateBox(cTpl);
        etBarTpl.setMinLines(1);
        note(cTpl, "بارکد فقط حروف و اعداد انگلیسی می‌پذیرد. روی لیبل کوچک، فقط عدد ({شماره}) خواناترین بارکد را می‌دهد.");

        label(cTpl, "فیلدهای دلخواه");
        etF1Name = textField(cTpl, "نام فیلد ۱");
        etF2Name = textField(cTpl, "نام فیلد ۲");
        note(cTpl, "مثلاً «سنگ» یا «قیمت». در قالب با {فیلد۱} یا با نام خودش مثل {سنگ} استفاده کنید.");

        label(cTpl, "شماره‌گذاری و پاک‌سازی");
        etCodeStep = numField(cTpl, "افزایش کد بعد از هر چاپ", "");
        cbClearWeight = check(cTpl, "بعد از چاپ، وزن پاک شود");
        cbClearWage = check(cTpl, "بعد از چاپ، اجرت پاک شود");

        // ---------------- connection
        LinearLayout cConn = card(root, "📡", "نوع اتصال چاپگر");
        rgConn = new RadioGroup(this);
        String[] conns = {"🔌  کابل USB (OTG)", "📶  وای‌فای / شبکه (IP)", "🔵  بلوتوث"};
        for (int i = 0; i < conns.length; i++) {
            RadioButton r = new RadioButton(this);
            r.setId(4000 + i);
            r.setText(conns[i]);
            r.setTextColor(C_TEXT);
            r.setTextSize(15);
            rgConn.addView(r);
        }
        rgConn.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            public void onCheckedChanged(RadioGroup g, int id) {
                if (id >= 4000) st.conn = id - 4000;
                updateUsbStatus();
            }
        });
        cConn.addView(rgConn);
        label(cConn, "وای‌فای / شبکه:");
        LinearLayout hostRow = hbox();
        TextView hl = new TextView(this);
        hl.setText("آدرس IP");
        hl.setTextColor(C_TEXT);
        hostRow.addView(hl, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        etHost = new EditText(this);
        etHost.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        etHost.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        etHost.setGravity(Gravity.CENTER);
        styleInput(etHost);
        etHost.addTextChangedListener(watcher);
        hostRow.addView(etHost, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1.6f));
        cConn.addView(hostRow, matchWrap(2));
        etPort = numField(cConn, "پورت", "");
        etPort.setInputType(InputType.TYPE_CLASS_NUMBER);
        label(cConn, "بلوتوث:");
        tvBt = note(cConn, "");
        buttonRow(cConn, 2, outline("🔵  انتخاب چاپگر بلوتوث", click(new Runnable() {
            public void run() { pickBluetooth(); }
        })));
        note(cConn, "برای بلوتوث، اول چاپگر را در تنظیمات بلوتوث گوشی جفت (Pair) کنید.");

        // ---------------- USB printer
        LinearLayout cUsb = card(root, "🖨", "زبان و کیفیت چاپگر");
        label(cUsb, "زبان چاپگر:");
        rgLang = new RadioGroup(this);
        String[] langs = {"TSPL — اکثر لیبل‌پرینترها (Xprinter، TSC، Gprinter، HPRT…)", "ZPL — Zebra", "ESC/POS — فیش‌پرینترها"};
        for (int i = 0; i < langs.length; i++) {
            RadioButton r = new RadioButton(this);
            r.setId(2000 + i);
            r.setText(langs[i]);
            r.setTextColor(C_TEXT);
            rgLang.addView(r);
        }
        rgLang.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            public void onCheckedChanged(RadioGroup g, int id) { if (id >= 2000) st.usbLang = id - 2000; }
        });
        cUsb.addView(rgLang);
        label(cUsb, "دقت چاپگر:");
        rgDpi = new RadioGroup(this);
        rgDpi.setOrientation(RadioGroup.HORIZONTAL);
        String[] dpis = {"203 dpi (رایج)", "300 dpi"};
        for (int i = 0; i < 2; i++) {
            RadioButton r = new RadioButton(this);
            r.setId(3000 + i);
            r.setText(dpis[i]);
            r.setTextColor(C_TEXT);
            rgDpi.addView(r);
        }
        rgDpi.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            public void onCheckedChanged(RadioGroup g, int id) { st.dpi = id == 3001 ? 300 : 203; }
        });
        cUsb.addView(rgDpi);
        etGap = numField(cUsb, "فاصله بین لیبل‌ها (Gap)", "mm");
        etDensity = numField(cUsb, "تیرگی چاپ (۰ تا ۱۵)", null);
        cbFlip = check(cUsb, "چاپ ۱۸۰ درجه برعکس شود");
        buttonRow(cUsb, 8, dark("⊹  چاپ تست USB", click(new Runnable() { public void run() { usbPrint(true); } })));

        // ---------------- position
        LinearLayout cPos = card(root, "✥", "تنظیم محل چاپ");
        tvOffset = new TextView(this);
        tvOffset.setGravity(Gravity.CENTER);
        tvOffset.setTextSize(12.5f);
        tvOffset.setTextColor(C_BROWN);
        tvOffset.setBackground(round(0xFFFBF3DD, 10, 0));
        tvOffset.setPadding(dp(8), dp(6), dp(8), dp(6));
        cPos.addView(tvOffset, matchWrap(0));
        note(cPos, "کادر قرمز در پیش‌نمایش، محل دقیق چاپ است. گام جابجایی:");
        RadioGroup rg = new RadioGroup(this);
        rg.setOrientation(RadioGroup.HORIZONTAL);
        rg.setGravity(Gravity.CENTER);
        final float[] steps = {0.1f, 0.25f, 0.5f, 1f};
        for (int i = 0; i < steps.length; i++) {
            RadioButton r = new RadioButton(this);
            r.setId(1000 + i);
            r.setText(LabelRenderer.fmt(steps[i]));
            r.setTextColor(C_TEXT);
            rg.addView(r);
            if (Math.abs(steps[i] - step) < 0.001f) r.setChecked(true);
        }
        rg.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            public void onCheckedChanged(RadioGroup g, int id) {
                int i = id - 1000;
                if (i >= 0 && i < steps.length) step = steps[i];
            }
        });
        cPos.addView(rg, matchWrap(0));

        LinearLayout pad = vbox();
        pad.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        pad.setGravity(Gravity.CENTER_HORIZONTAL);
        pad.setBackground(round(0xFFFBF7EC, 18, 0xFFEFE3C6));
        pad.setPadding(dp(8), dp(10), dp(8), dp(10));
        LinearLayout r1 = hbox(), r2 = hbox(), r3 = hbox();
        r1.setGravity(Gravity.CENTER);
        r2.setGravity(Gravity.CENTER);
        r3.setGravity(Gravity.CENTER);
        r1.addView(arrow("▲\nبالا", 0, -1));
        r2.addView(arrow("◀\nچپ", -1, 0));
        Button center = dark("●\nمرکز", click(new Runnable() {
            public void run() { st.offsetX = 0; st.offsetY = 0; settingsToUi(); refresh(); }
        }));
        r2.addView(center, arrowLp());
        r2.addView(arrow("▶\nراست", 1, 0));
        r3.addView(arrow("▼\nپایین", 0, 1));
        pad.addView(r1);
        pad.addView(r2);
        pad.addView(r3);
        cPos.addView(pad, matchWrap(8));
        etOffX = numField(cPos, "افقی X  (+ راست / − چپ)", "mm");
        etOffY = numField(cPos, "عمودی Y  (+ پایین / − بالا)", "mm");

        // ---------------- size
        LinearLayout cSize = card(root, "📐", "اندازه لیبل");
        etW = numField(cSize, "عرض کل لیبل", "mm");
        etH = numField(cSize, "ارتفاع لیبل", "mm");
        etTail = numField(cSize, "طول دم", "mm");
        cbFold = check(cSize, "لیبل از وسط تا می‌شود (دو رو)");
        cbTail = check(cSize, "دم جزو صفحه چاپ است");
        cbTailLeft = check(cSize, "دم در سمت چپ لیبل است");

        // ---------------- style
        LinearLayout cStyle = card(root, "Aa", "ظاهر متن");
        etFont = numField(cStyle, "اندازه قلم", "mm");
        etPad = numField(cStyle, "فاصله متن از لبه", "mm");
        cbBold = check(cStyle, "قلم ضخیم");
        cbFa = check(cStyle, "اعداد فارسی (۱۲۳)");
        cbRotB = check(cStyle, "پشت لیبل ۱۸۰ درجه بچرخد");
        cbRotPage = check(cStyle, "صفحه ۹۰ درجه بچرخد");
        cbBorder = check(cStyle, "چاپ کادر دور لیبل");
    }

    private android.widget.Spinner spinner(LinearLayout parent, String label, String[] items) {
        LinearLayout row = hbox();
        row.setPadding(0, dp(4), 0, dp(4));
        TextView tv = new TextView(this);
        tv.setText(label);
        tv.setTextColor(C_TEXT);
        row.addView(tv, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        android.widget.Spinner sp = new android.widget.Spinner(this);
        android.widget.ArrayAdapter<String> ad = new android.widget.ArrayAdapter<>(this,
                android.R.layout.simple_spinner_dropdown_item, items);
        sp.setAdapter(ad);
        sp.setBackground(round(0xFFFBF8F1, 12, 0xFFE3D5B0));
        sp.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener() {
            public void onItemSelected(android.widget.AdapterView<?> p, View v, int pos, long id) { onUiChanged(); }
            public void onNothingSelected(android.widget.AdapterView<?> p) {}
        });
        row.addView(sp, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1.8f));
        parent.addView(row);
        return sp;
    }

    private EditText templateBox(LinearLayout parent) {
        EditText e = new EditText(this);
        e.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE);
        e.setMinLines(3);
        e.setGravity(Gravity.TOP | Gravity.START);
        styleInput(e);
        e.addTextChangedListener(watcher);
        parent.addView(e, matchWrap(4));
        return e;
    }

    private EditText textField(LinearLayout parent, String label) {
        EditText e = numField(parent, label, "");
        e.setInputType(InputType.TYPE_CLASS_TEXT);
        e.setTypeface(Typeface.DEFAULT);
        return e;
    }

    /** Ready-made layouts the user can start from. */
    private void templatePresets() {
        final String[] names = {
                "متن دوطرفه (عیار و وزن | کد و اجرت)",
                "متن سه‌خطی + QR",
                "متن + بارکد",
                "QR کنار متن + متن",
                "با نام گالری (سطر اول درشت)",
                "سه سطر هر طرف + فیلدهای دلخواه"};
        new AlertDialog.Builder(this)
                .setTitle("قالب‌های آماده")
                .setItems(names, (d, which) -> {
                    uiToSettings();
                    st.alignA = 0;
                    st.alignB = 0;
                    switch (which) {
                        case 0:
                            st.typeA = LabelSettings.T_TEXT; st.tplA = "{عیار} عیار\nوزن: {وزن}";
                            st.typeB = LabelSettings.T_TEXT; st.tplB = "{کد}\nاجرت: {اجرت}%";
                            break;
                        case 1:
                            st.typeA = LabelSettings.T_TEXT; st.tplA = "{کد}\nاجرت: {اجرت}%\nوزن: {وزن}";
                            st.typeB = LabelSettings.T_QR; st.tplB = "";
                            break;
                        case 2:
                            st.typeA = LabelSettings.T_TEXT; st.tplA = "{عیار} عیار\nوزن: {وزن}\nاجرت: {اجرت}%";
                            st.typeB = LabelSettings.T_BAR_TEXT; st.tplB = "{کد}";
                            st.barTpl = "{شماره}";
                            break;
                        case 3:
                            st.typeA = LabelSettings.T_QR_TEXT; st.tplA = "{کد}\n{وزن}"; st.alignA = 1;
                            st.typeB = LabelSettings.T_TEXT; st.tplB = "{عیار} عیار\nاجرت: {اجرت}%";
                            break;
                        case 4:
                            st.typeA = LabelSettings.T_TEXT; st.tplA = "#گالری انصاری\n{کد}\nوزن: {وزن}";
                            st.typeB = LabelSettings.T_TEXT; st.tplB = "{عیار} عیار\nاجرت: {اجرت}%";
                            break;
                        default:
                            st.typeA = LabelSettings.T_TEXT; st.tplA = "{کد}\nوزن: {وزن}\n{فیلد۱}";
                            st.typeB = LabelSettings.T_TEXT; st.tplB = "{عیار} عیار\nاجرت: {اجرت}%\n{فیلد۲}";
                    }
                    if (st.typeA == LabelSettings.T_QR || st.typeB == LabelSettings.T_QR
                            || st.typeA == LabelSettings.T_QR_TEXT) {
                        if (st.qrTpl.trim().isEmpty()) st.qrTpl = "{کد}/{وزن}/{اجرت}/{عیار}";
                    }
                    settingsToUi();
                    refresh();
                    toast("قالب «" + names[which] + "» اعمال شد؛ برای ماندگاری «ذخیره پروفایل» را بزنید");
                })
                .setNegativeButton("بستن", null)
                .show();
    }

    private LinearLayout.LayoutParams arrowLp() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(84), dp(64));
        lp.setMargins(dp(5), dp(4), dp(5), dp(4));
        return lp;
    }

    private Button arrow(String text, final int dx, final int dy) {
        Button b = primary(text, click(new Runnable() { public void run() { move(dx, dy); } }));
        b.setTextSize(13);
        b.setMinHeight(0);
        b.setPadding(0, dp(4), 0, dp(4));
        b.setLayoutParams(arrowLp());
        return b;
    }

    // ================================================================= quick-entry logic

    private static String t(EditText e) {
        return e.getText().toString().trim();
    }

    private String today() {
        try {
            android.icu.text.SimpleDateFormat f = new android.icu.text.SimpleDateFormat(
                    "yyyy/MM/dd", new android.icu.util.ULocale("en_US@calendar=persian"));
            return f.format(new java.util.Date());
        } catch (Throwable e) {
            return new java.text.SimpleDateFormat("yyyy/MM/dd", java.util.Locale.US).format(new java.util.Date());
        }
    }

    /** Placeholder → value. code=true makes values safe for QR/barcode (Latin digits, no '/'). */
    private String[][] values(boolean code) {
        String c = etPrefix.getText().toString().trim() + t(etCode);
        String[][] m = {
                {"{کد}", t(etCode).isEmpty() ? "" : c},
                {"{شماره}", t(etCode)},
                {"{وزن}", t(etWeight)},
                {"{اجرت}", t(etWage)},
                {"{عیار}", t(etKarat)},
                {"{تاریخ}", today()},
                {"{فیلد۱}", t(etF1)},
                {"{فیلد۲}", t(etF2)},
                {"{" + st.f1Name.trim() + "}", t(etF1)},
                {"{" + st.f2Name.trim() + "}", t(etF2)},
        };
        if (code) for (String[] kv : m) kv[1] = latin(kv[1]);
        return m;
    }

    /** Fills a text template; a line whose placeholder value is empty is dropped. */
    private String fill(String tpl) {
        String[][] map = values(false);
        StringBuilder out = new StringBuilder();
        for (String line : tpl.split("\n", -1)) {
            boolean drop = false;
            String l = line;
            for (String[] kv : map) {
                if (kv[0].length() > 2 && l.contains(kv[0])) {
                    if (kv[1].isEmpty()) drop = true;
                    l = l.replace(kv[0], kv[1]);
                }
            }
            if (drop) continue;
            if (out.length() > 0) out.append('\n');
            out.append(l);
        }
        return out.toString();
    }

    private String fillCode(String tpl) {
        String l = tpl.replace("\n", "").trim();
        for (String[] kv : values(true)) if (kv[0].length() > 2) l = l.replace(kv[0], kv[1]);
        boolean ascii = true;
        for (char ch : l.toCharArray()) if (ch > 127) { ascii = false; break; }
        return ascii ? l.toUpperCase(java.util.Locale.US) : l;
    }

    private boolean uses(int type) {
        return st.typeA == type || (st.fold && st.typeB == type);
    }

    private String textA() { return fill(st.tplA); }

    private String textB() { return fill(st.tplB); }

    private static String latin(String in) {
        StringBuilder sb = new StringBuilder();
        for (char ch : in.toCharArray()) {
            if (ch >= '\u06F0' && ch <= '\u06F9') sb.append((char) ('0' + ch - '\u06F0'));
            else if (ch >= '\u0660' && ch <= '\u0669') sb.append((char) ('0' + ch - '\u0660'));
            else if (ch == '/') sb.append('-');
            else sb.append(ch);
        }
        return sb.toString();
    }

    private String qrPayload() {
        if (!(uses(LabelSettings.T_QR) || uses(LabelSettings.T_QR_TEXT))) return null;
        String q = fillCode(st.qrTpl);
        return q.isEmpty() ? null : q;
    }

    private String barPayload() {
        if (!(uses(LabelSettings.T_BAR) || uses(LabelSettings.T_BAR_TEXT))) return null;
        String b = fillCode(st.barTpl);
        return b.isEmpty() ? null : b;
    }

    /** Is a placeholder used anywhere in the active templates? */
    private boolean used(String... keys) {
        String all = st.tplA + "\n" + (st.fold ? st.tplB : "");
        if (qrPayload() != null) all += st.qrTpl;
        if (barPayload() != null) all += st.barTpl;
        for (String k : keys) if (all.contains(k)) return true;
        return false;
    }

    private void showRow(EditText e, boolean show) {
        View row = (View) e.getParent();
        if (row != null) row.setVisibility(show ? View.VISIBLE : View.GONE);
    }

    private void updateQuickFields() {
        showRow(etWeight, used("{وزن}"));
        showRow(etWage, used("{اجرت}"));
        showRow(etKarat, used("{عیار}"));
        showRow(etF1, used("{فیلد۱}", "{" + st.f1Name.trim() + "}"));
        showRow(etF2, used("{فیلد۲}", "{" + st.f2Name.trim() + "}"));
        // the last visible field prints on «Done»; the others move to the next field
        EditText[] order = {etWeight, etWage, etF1, etF2};
        EditText last = null;
        for (EditText e : order) if (((View) e.getParent()).getVisibility() == View.VISIBLE) last = e;
        for (EditText e : order) e.setImeOptions(e == last ? EditorInfo.IME_ACTION_DONE : EditorInfo.IME_ACTION_NEXT);
        etKarat.setImeOptions(last == null ? EditorInfo.IME_ACTION_DONE : EditorInfo.IME_ACTION_NEXT);
        setRowLabel(etF1, st.f1Name.trim().isEmpty() ? "فیلد ۱" : st.f1Name.trim());
        setRowLabel(etF2, st.f2Name.trim().isEmpty() ? "فیلد ۲" : st.f2Name.trim());
    }

    private void setRowLabel(EditText e, String text) {
        View row = (View) e.getParent();
        if (row instanceof LinearLayout && ((LinearLayout) row).getChildCount() > 0
                && ((LinearLayout) row).getChildAt(0) instanceof TextView) {
            ((TextView) ((LinearLayout) row).getChildAt(0)).setText(text);
        }
    }

    private void bumpCode(int dir) {
        String s = t(etCode);
        String digits = s.replaceAll("[^0-9]", "");
        if (digits.isEmpty()) digits = "0";
        long n;
        try { n = Long.parseLong(digits); } catch (Exception e) { n = 0; }
        n = Math.max(0, n + (long) dir * Math.max(1, st.codeStep));
        String ns = String.valueOf(n);
        while (ns.length() < s.length()) ns = "0" + ns; // keep leading zeros
        etCode.setText(ns);
    }

    private void afterSuccessfulPrint() {
        bumpCode(1);
        if (st.clearWeight) etWeight.setText("");
        if (st.clearWage) etWage.setText("");
        saveQuickState();
        etWeight.requestFocus();
    }

    // ================================================================= USB

    private void updateUsbStatus() {
        if (tvUsb == null) return;
        if (tvBt != null) tvBt.setText(st.btAddress.isEmpty() ? "هنوز انتخاب نشده" : "انتخاب‌شده: " + st.btName + "  (" + st.btAddress + ")");
        if (st.conn == 1) {
            tvUsb.setText("📶  شبکه: " + st.netHost + ":" + st.netPort);
            tvUsb.setTextColor(0xFFB3E5FC);
            return;
        }
        if (st.conn == 2) {
            tvUsb.setText(st.btAddress.isEmpty() ? "🔵  چاپگر بلوتوث انتخاب نشده" : "🔵  بلوتوث: " + st.btName);
            tvUsb.setTextColor(0xFFBBDEFB);
            return;
        }
        UsbDevice d = usb.find();
        if (d == null) {
            tvUsb.setText("⚪  چاپگر وصل نیست  (لمس برای جستجو)");
            tvUsb.setTextColor(0xFFE8DCC0);
        } else {
            tvUsb.setText("🟢  " + UsbPrinter.describe(d));
            tvUsb.setTextColor(0xFFB9F6CA);
        }
    }

    private void usbPrint(final boolean test) {
        if (printing) return;
        uiToSettings();
        if (!test && t(etWeight).isEmpty() && used("{وزن}")) {
            etWeight.requestFocus();
            toast("وزن را وارد کنید");
            return;
        }
        byte[] data;
        try {
            data = PrinterCommands.build(st.copy(), textA(), textB(), test ? null : qrPayload(),
                    test ? null : barPayload(), 1, test);
        } catch (Exception e) {
            toast("خطا در ساخت لیبل: " + e.getMessage());
            return;
        }
        printing = true;
        final String printedCode = etPrefix.getText().toString().trim() + t(etCode);
        UsbPrinter.Callback cb = new UsbPrinter.Callback() {
            public void onResult(boolean ok, String msg) {
                printing = false;
                updateUsbStatus();
                if (ok) {
                    if (!test) {
                        afterSuccessfulPrint();
                        toast("✓ چاپ شد: " + printedCode);
                    } else {
                        toast("تست ارسال شد ✓");
                    }
                } else if (msg != null) {
                    new AlertDialog.Builder(MainActivity.this)
                            .setMessage(msg)
                            .setPositiveButton("باشه", null)
                            .show();
                }
            }
        };
        if (st.conn == 1) {
            NetPrinter.send(this, st.netHost, st.netPort, data, cb);
        } else if (st.conn == 2) {
            if (st.btAddress.isEmpty()) { printing = false; pickBluetooth(); return; }
            if (BtPrinter.needPermission(this)) { printing = false; BtPrinter.askPermission(this); return; }
            BtPrinter.send(this, st.btAddress, data, cb);
        } else {
            usb.send(data, cb);
        }
    }

    private void pickBluetooth() {
        if (BtPrinter.needPermission(this)) {
            BtPrinter.askPermission(this);
            return;
        }
        final List<android.bluetooth.BluetoothDevice> list = BtPrinter.bonded();
        if (list == null) { toast("بلوتوث گوشی را روشن کنید"); return; }
        if (list.isEmpty()) {
            toast("دستگاه جفت‌شده‌ای نیست؛ اول چاپگر را در تنظیمات بلوتوث گوشی جفت کنید");
            try { startActivity(new Intent(android.provider.Settings.ACTION_BLUETOOTH_SETTINGS)); } catch (Exception ignored) {}
            return;
        }
        String[] names = new String[list.size()];
        for (int i = 0; i < names.length; i++) names[i] = BtPrinter.name(list.get(i)) + "\n" + list.get(i).getAddress();
        new AlertDialog.Builder(this)
                .setTitle("انتخاب چاپگر بلوتوث")
                .setItems(names, (d, which) -> {
                    st.btAddress = list.get(which).getAddress();
                    st.btName = BtPrinter.name(list.get(which));
                    st.conn = 2;
                    settingsToUi();
                    updateUsbStatus();
                    toast("انتخاب شد: " + st.btName);
                })
                .show();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 77 && grantResults.length > 0
                && grantResults[0] == android.content.pm.PackageManager.PERMISSION_GRANTED) {
            if (st.btAddress.isEmpty()) pickBluetooth();
            else toast("اجازه داده شد؛ دوباره چاپ را بزنید");
        }
    }

    // ================================================================= state sync

    private static float round2(float v) {
        return Math.round(v * 100f) / 100f;
    }

    private void move(int dx, int dy) {
        st.offsetX = round2(st.offsetX + dx * step);
        st.offsetY = round2(st.offsetY + dy * step);
        updating = true;
        etOffX.setText(LabelRenderer.fmt(st.offsetX));
        etOffY.setText(LabelRenderer.fmt(st.offsetY));
        updating = false;
        refresh();
    }

    private static float parse(EditText e, float def) {
        String s = e.getText().toString().trim();
        StringBuilder sb = new StringBuilder();
        for (char ch : s.toCharArray()) {
            if (ch >= '۰' && ch <= '۹') sb.append((char) ('0' + ch - '۰'));
            else if (ch >= '٠' && ch <= '٩') sb.append((char) ('0' + ch - '٠'));
            else if (ch == '٫' || ch == ',' || ch == '/') sb.append('.');
            else if (ch == '−') sb.append('-');
            else sb.append(ch);
        }
        try {
            return Float.parseFloat(sb.toString());
        } catch (Exception ex) {
            return def;
        }
    }

    private void settingsToUi() {
        updating = true;
        etW.setText(LabelRenderer.fmt(st.labelWidth));
        etH.setText(LabelRenderer.fmt(st.labelHeight));
        etTail.setText(LabelRenderer.fmt(st.tailLength));
        etOffX.setText(LabelRenderer.fmt(st.offsetX));
        etOffY.setText(LabelRenderer.fmt(st.offsetY));
        etPad.setText(LabelRenderer.fmt(st.padding));
        etFont.setText(LabelRenderer.fmt(st.fontSize));
        cbFold.setChecked(st.fold);
        cbTail.setChecked(st.includeTail);
        cbTailLeft.setChecked(st.tailLeft);
        cbRotB.setChecked(st.rotateBack);
        cbRotPage.setChecked(st.rotatePage);
        cbBold.setChecked(st.bold);
        cbFa.setChecked(st.persianDigits);
        cbBorder.setChecked(st.printBorder);
        etGap.setText(LabelRenderer.fmt(st.gapMm));
        etDensity.setText(String.valueOf(st.density));
        cbFlip.setChecked(st.usbFlip);
        int lang = st.usbLang, dpi = st.dpi;
        rgLang.check(2000 + Math.max(0, Math.min(2, lang)));
        rgDpi.check(dpi >= 300 ? 3001 : 3000);
        int conn = st.conn;
        rgConn.check(4000 + Math.max(0, Math.min(2, conn)));
        etHost.setText(st.netHost);
        etPort.setText(String.valueOf(st.netPort));
        etTplA.setText(st.tplA);
        etTplB.setText(st.tplB);
        etCodeStep.setText(String.valueOf(st.codeStep));
        cbClearWeight.setChecked(st.clearWeight);
        cbClearWage.setChecked(st.clearWage);
        spTypeA.setSelection(Math.max(0, Math.min(4, st.typeA)));
        spTypeB.setSelection(Math.max(0, Math.min(4, st.typeB)));
        spAlignA.setSelection(Math.max(0, Math.min(2, st.alignA)));
        spAlignB.setSelection(Math.max(0, Math.min(2, st.alignB)));
        etQrTpl.setText(st.qrTpl);
        etBarTpl.setText(st.barTpl);
        etF1Name.setText(st.f1Name);
        etF2Name.setText(st.f2Name);
        if (etPrefix != null) etPrefix.setText(st.codePrefix);
        updating = false;
        if (tvProfile != null) tvProfile.setText("👤  پروفایل: " + profileName + "   (لمس برای تغییر)");
    }

    private void uiToSettings() {
        float w = parse(etW, st.labelWidth);
        float h = parse(etH, st.labelHeight);
        if (w > 1) st.labelWidth = w;
        if (h > 1) st.labelHeight = h;
        st.tailLength = Math.max(0, parse(etTail, st.tailLength));
        st.offsetX = parse(etOffX, st.offsetX);
        st.offsetY = parse(etOffY, st.offsetY);
        st.padding = Math.max(0, parse(etPad, st.padding));
        float f = parse(etFont, st.fontSize);
        if (f > 0.3f) st.fontSize = f;
        st.fold = cbFold.isChecked();
        st.includeTail = cbTail.isChecked();
        st.tailLeft = cbTailLeft.isChecked();
        st.rotateBack = cbRotB.isChecked();
        st.rotatePage = cbRotPage.isChecked();
        st.bold = cbBold.isChecked();
        st.persianDigits = cbFa.isChecked();
        st.printBorder = cbBorder.isChecked();
        st.gapMm = Math.max(0, parse(etGap, st.gapMm));
        st.density = Math.round(Math.max(0, Math.min(15, parse(etDensity, st.density))));
        st.usbFlip = cbFlip.isChecked();
        String host = etHost.getText().toString().trim();
        if (!host.isEmpty()) st.netHost = host;
        st.netPort = Math.max(1, Math.round(parse(etPort, st.netPort)));
        st.tplA = etTplA.getText().toString();
        st.tplB = etTplB.getText().toString();
        st.codeStep = Math.max(1, Math.round(parse(etCodeStep, st.codeStep)));
        st.clearWeight = cbClearWeight.isChecked();
        st.clearWage = cbClearWage.isChecked();
        st.typeA = spTypeA.getSelectedItemPosition();
        st.typeB = spTypeB.getSelectedItemPosition();
        st.alignA = spAlignA.getSelectedItemPosition();
        st.alignB = spAlignB.getSelectedItemPosition();
        st.qrTpl = etQrTpl.getText().toString();
        st.barTpl = etBarTpl.getText().toString();
        st.f1Name = etF1Name.getText().toString().trim();
        st.f2Name = etF2Name.getText().toString().trim();
        st.codePrefix = etPrefix.getText().toString().trim();
    }

    private void onUiChanged() {
        if (updating || etKarat == null || cbBorder == null) return;
        uiToSettings();
        refresh();
    }

    private void refresh() {
        if (preview == null || etKarat == null) return;
        preview.setData(st, textA(), textB(), qrPayload(), barPayload());
        updateQuickFields();
        if (tvOffset != null) {
            tvOffset.setText("X = " + LabelRenderer.fmt(st.offsetX) + " mm     Y = "
                    + LabelRenderer.fmt(st.offsetY) + " mm     صفحه "
                    + LabelRenderer.fmt(LabelRenderer.pageWidth(st)) + "×" + LabelRenderer.fmt(st.labelHeight));
        }
    }

    // ================================================================= profiles

    private void toast(String m) {
        Toast.makeText(this, m, Toast.LENGTH_SHORT).show();
    }

    private void applyProfile(String name, String json) {
        profileName = name;
        st.applyJson(json);
        settingsToUi();
        refresh();
        updateUsbStatus();
        saveQuickState();
    }

    // ---------------------------------------------------------------- profile backup

    private static final int REQ_EXPORT = 31, REQ_IMPORT = 32;

    /** All saved profiles + the default, as one JSON backup. */
    private String profilesBackup() throws Exception {
        uiToSettings();
        JSONObject p = presets();
        JSONObject out = new JSONObject();
        out.put("app", "GoldLabel");
        out.put("version", 1);
        out.put("exported", today());
        out.put("defaultName", prefs.getString(P_DEFAULT_NAME, ""));
        JSONObject profs = new JSONObject();
        Iterator<String> it = p.keys();
        while (it.hasNext()) {
            String n = it.next();
            profs.put(n, new JSONObject(p.optString(n, "{}")));
        }
        if (profs.length() == 0) profs.put(profileName, new JSONObject(st.toJson())); // nothing saved yet → current
        out.put("profiles", profs);
        return out.toString(2);
    }

    private void exportProfiles() {
        Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("application/json");
        i.putExtra(Intent.EXTRA_TITLE, "gold_profiles_" + today().replace('/', '-') + ".json");
        try {
            startActivityForResult(i, REQ_EXPORT);
        } catch (Exception e) {
            toast("امکان ذخیره فایل وجود ندارد");
        }
    }

    private void importProfiles() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        try {
            startActivityForResult(i, REQ_IMPORT);
        } catch (Exception e) {
            toast("امکان باز کردن فایل وجود ندارد");
        }
    }

    private void shareProfiles() {
        try {
            Intent s = new Intent(Intent.ACTION_SEND);
            s.setType("text/plain");
            s.putExtra(Intent.EXTRA_SUBJECT, "پروفایل‌های لیبل گالری انصاری");
            s.putExtra(Intent.EXTRA_TEXT, profilesBackup());
            startActivity(Intent.createChooser(s, "ارسال پروفایل‌ها"));
        } catch (Exception e) {
            toast("خطا: " + e.getMessage());
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null || data.getData() == null) return;
        if (requestCode == REQ_EXPORT) {
            java.io.OutputStream os = null;
            try {
                os = getContentResolver().openOutputStream(data.getData());
                os.write(profilesBackup().getBytes(java.nio.charset.Charset.forName("UTF-8")));
                toast("پروفایل‌ها در فایل ذخیره شد ✓");
            } catch (Exception e) {
                toast("خطا در ذخیره: " + e.getMessage());
            } finally {
                if (os != null) try { os.close(); } catch (Exception ignored) {}
            }
        } else if (requestCode == REQ_IMPORT) {
            java.io.InputStream is = null;
            try {
                is = getContentResolver().openInputStream(data.getData());
                java.io.ByteArrayOutputStream bo = new java.io.ByteArrayOutputStream();
                byte[] buf = new byte[8192];
                int n;
                while ((n = is.read(buf)) > 0) {
                    bo.write(buf, 0, n);
                    if (bo.size() > 2_000_000) throw new IllegalStateException("فایل خیلی بزرگ است");
                }
                String text = new String(bo.toByteArray(), java.nio.charset.Charset.forName("UTF-8"));
                importBackup(text);
            } catch (Exception e) {
                toast("این فایل، فایل پروفایل معتبر نیست");
            } finally {
                if (is != null) try { is.close(); } catch (Exception ignored) {}
            }
        }
    }

    private void importBackup(String text) throws Exception {
        String t = text.trim();
        if (t.startsWith("\uFEFF")) t = t.substring(1);
        int b = t.indexOf('{');
        if (b > 0) t = t.substring(b); // tolerate text pasted before the JSON
        JSONObject in = new JSONObject(t);
        JSONObject profs = in.optJSONObject("profiles");
        if (profs == null) {
            if (!in.has("labelWidth")) throw new IllegalArgumentException();
            profs = new JSONObject();
            profs.put("وارد‌شده", in); // a single bare profile
        }
        final JSONObject p = presets();
        final List<String> names = new ArrayList<>();
        Iterator<String> it = profs.keys();
        while (it.hasNext()) {
            String n = it.next();
            JSONObject o = profs.optJSONObject(n);
            if (o == null) continue;
            LabelSettings clean = new LabelSettings();
            clean.applyJson(o.toString()); // validates & fills missing values
            p.put(n, clean.toJson());
            names.add(n);
        }
        if (names.isEmpty()) throw new IllegalArgumentException();
        prefs.edit().putString(P_PRESETS, p.toString()).apply();
        final String fileDefault = in.optString("defaultName", "");
        StringBuilder msg = new StringBuilder(names.size() + " پروفایل وارد شد:\n");
        for (String n : names) msg.append("• ").append(n).append('\n');
        msg.append("\nپروفایل‌های هم‌نام قبلی جایگزین شدند.");
        AlertDialog.Builder d = new AlertDialog.Builder(this)
                .setTitle("بارگذاری از فایل ✓")
                .setMessage(msg.toString())
                .setNegativeButton("بستن", null)
                .setNeutralButton("انتخاب پروفایل", (dd, w) -> loadPresetDialog());
        if (!fileDefault.isEmpty() && names.contains(fileDefault)) {
            d.setPositiveButton("استفاده از «" + fileDefault + "» و پیش‌فرض", (dd, w) -> {
                String json = p.optString(fileDefault, "{}");
                prefs.edit().putString(P_DEFAULT, json).putString(P_DEFAULT_NAME, fileDefault).apply();
                applyProfile(fileDefault, json);
                toast("«" + fileDefault + "» بارگذاری و پیش‌فرض شد");
            });
        }
        d.show();
    }

    private void factoryReset() {
        new AlertDialog.Builder(this)
                .setMessage("همه تنظیمات به حالت کارخانه (۴۴×۱۰ و دم ۴۵ میلی‌متر) برگردد؟")
                .setPositiveButton("بله", (d, w) -> {
                    applyProfile("کارخانه", new LabelSettings().toJson());
                    toast("برای ماندگاری، «ذخیره پروفایل» را بزنید");
                })
                .setNegativeButton("خیر", null)
                .show();
    }

    private JSONObject presets() {
        try {
            return new JSONObject(prefs.getString(P_PRESETS, "{}"));
        } catch (Exception e) {
            return new JSONObject();
        }
    }

    private void savePresetDialog() {
        uiToSettings();
        LinearLayout box = vbox();
        box.setPadding(dp(20), dp(8), dp(20), 0);
        final EditText name = new EditText(this);
        name.setHint("نام پروفایل (مثلاً انگشتر، گردنبند)");
        name.setText(profileName);
        name.setSelectAllOnFocus(true);
        box.addView(name);
        final CheckBox asDef = new CheckBox(this);
        asDef.setText("پروفایل پیش‌فرض باشد (هنگام باز شدن برنامه)");
        asDef.setChecked(true);
        box.addView(asDef);
        new AlertDialog.Builder(this)
                .setTitle("ذخیره پروفایل")
                .setView(box)
                .setPositiveButton("ذخیره", (d, w) -> {
                    String n = name.getText().toString().trim();
                    if (n.isEmpty()) { toast("نام را وارد کنید"); return; }
                    try {
                        JSONObject p = presets();
                        p.put(n, st.toJson());
                        SharedPreferences.Editor ed = prefs.edit().putString(P_PRESETS, p.toString());
                        if (asDef.isChecked()) ed.putString(P_DEFAULT, st.toJson()).putString(P_DEFAULT_NAME, n);
                        ed.apply();
                        profileName = n;
                        settingsToUi();
                        saveQuickState();
                        toast("پروفایل «" + n + "» ذخیره شد ✓");
                    } catch (Exception e) {
                        toast("خطا در ذخیره");
                    }
                })
                .setNegativeButton("انصراف", null)
                .show();
    }

    private void loadPresetDialog() {
        final JSONObject p = presets();
        final List<String> names = new ArrayList<>();
        Iterator<String> it = p.keys();
        while (it.hasNext()) names.add(it.next());
        Collections.sort(names);
        if (names.isEmpty()) {
            toast("هنوز پروفایلی ذخیره نشده — از «تنظیمات و پروفایل» ذخیره کنید");
            return;
        }
        final String defName = prefs.getString(P_DEFAULT_NAME, "");
        String[] shown = new String[names.size()];
        for (int i = 0; i < shown.length; i++) {
            shown[i] = names.get(i) + (names.get(i).equals(defName) ? "   ★ پیش‌فرض" : "");
        }
        new AlertDialog.Builder(this)
                .setTitle("انتخاب پروفایل")
                .setItems(shown, (d, which) -> {
                    String n = names.get(which);
                    applyProfile(n, p.optString(n, "{}"));
                    toast("پروفایل «" + n + "» بارگذاری شد");
                })
                .setNeutralButton("مدیریت…", (d, w) -> manageDialog(p, names))
                .setNegativeButton("بستن", null)
                .show();
    }

    private void manageDialog(final JSONObject p, final List<String> names) {
        new AlertDialog.Builder(this)
                .setTitle("کدام پروفایل؟")
                .setItems(names.toArray(new String[0]), (d, which) -> {
                    final String n = names.get(which);
                    String[] actions = {"پیش‌فرض شود ★", "حذف"};
                    new AlertDialog.Builder(this)
                            .setTitle(n)
                            .setItems(actions, (d2, a) -> {
                                if (a == 0) {
                                    prefs.edit().putString(P_DEFAULT, p.optString(n, "{}"))
                                            .putString(P_DEFAULT_NAME, n).apply();
                                    toast("«" + n + "» پیش‌فرض شد");
                                } else {
                                    p.remove(n);
                                    prefs.edit().putString(P_PRESETS, p.toString()).apply();
                                    toast("حذف شد");
                                }
                            })
                            .show();
                })
                .show();
    }
}
