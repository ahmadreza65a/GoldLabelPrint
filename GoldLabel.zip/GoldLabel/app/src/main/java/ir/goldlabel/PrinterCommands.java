package ir.goldlabel;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;

import java.io.ByteArrayOutputStream;
import java.nio.charset.Charset;
import java.util.Locale;

/** Renders the label to a 1-bit image and wraps it in TSPL / ZPL / ESC-POS commands. */
public final class PrinterCommands {
    public static final int LANG_TSPL = 0, LANG_ZPL = 1, LANG_ESCPOS = 2;
    private static final Charset ASCII = Charset.forName("US-ASCII");

    private PrinterCommands() {}

    private static class Mono {
        int w, h, wb;
        byte[] data; // 1 = black, MSB first
    }

    private static Mono render(LabelSettings st, String a, String b, String qr, boolean test) {
        float dpmm = st.dpi / 25.4f;
        int w = Math.max(8, Math.round(LabelRenderer.pageWidth(st) * dpmm));
        int h = Math.max(8, Math.round(st.labelHeight * dpmm));
        int bw = st.rotatePage ? h : w;
        int bh = st.rotatePage ? w : h;
        Bitmap bm = Bitmap.createBitmap(bw, bh, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(bm);
        c.drawColor(Color.WHITE);
        if (st.rotatePage) {
            c.translate(bw, 0);
            c.rotate(90);
        }
        LabelRenderer.draw(c, dpmm, st, a, b, qr, test);

        Mono m = new Mono();
        m.w = bw;
        m.h = bh;
        m.wb = (bw + 7) / 8;
        m.data = new byte[m.wb * bh];
        int[] row = new int[bw];
        for (int y = 0; y < bh; y++) {
            bm.getPixels(row, 0, bw, 0, y, bw, 1);
            for (int x = 0; x < bw; x++) {
                int p = row[x];
                int lum = (Color.red(p) * 30 + Color.green(p) * 59 + Color.blue(p) * 11) / 100;
                if (lum < 150) m.data[y * m.wb + (x >> 3)] |= (byte) (0x80 >> (x & 7));
            }
        }
        bm.recycle();
        return m;
    }

    public static byte[] build(LabelSettings st, String a, String b, String qr, int copies, boolean test) {
        Mono m = render(st, a, b, qr, test);
        copies = Math.max(1, copies);
        switch (st.usbLang) {
            case LANG_ZPL: return zpl(st, m, copies);
            case LANG_ESCPOS: return escpos(m, copies);
            default: return tspl(st, m, copies);
        }
    }

    private static byte[] tspl(LabelSettings st, Mono m, int copies) {
        float dpmm = st.dpi / 25.4f;
        ByteArrayOutputStream o = new ByteArrayOutputStream();
        String head = String.format(Locale.US,
                "SIZE %s mm,%s mm\r\nGAP %s mm,0 mm\r\nDENSITY %d\r\nDIRECTION %d\r\nREFERENCE 0,0\r\nCLS\r\nBITMAP 0,0,%d,%d,0,",
                LabelRenderer.fmt(m.w / dpmm), LabelRenderer.fmt(m.h / dpmm),
                LabelRenderer.fmt(st.gapMm), clamp(st.density, 0, 15), st.usbFlip ? 0 : 1, m.wb, m.h);
        o.write(head.getBytes(ASCII), 0, head.length());
        byte[] inv = new byte[m.data.length]; // TSPL: 0 = black
        for (int i = 0; i < inv.length; i++) inv[i] = (byte) ~m.data[i];
        o.write(inv, 0, inv.length);
        byte[] tail = String.format(Locale.US, "\r\nPRINT %d,1\r\n", copies).getBytes(ASCII);
        o.write(tail, 0, tail.length);
        return o.toByteArray();
    }

    private static byte[] zpl(LabelSettings st, Mono m, int copies) {
        StringBuilder hex = new StringBuilder(m.data.length * 2);
        final char[] H = "0123456789ABCDEF".toCharArray();
        for (byte v : m.data) {
            hex.append(H[(v >> 4) & 0xF]).append(H[v & 0xF]);
        }
        String s = String.format(Locale.US,
                "^XA^PW%d^LL%d^LH0,0~SD%02d%s^FO0,0^GFA,%d,%d,%d,%s^FS^PQ%d^XZ\r\n",
                m.w, m.h, clamp(st.density * 2, 0, 30), st.usbFlip ? "^POI" : "^PON",
                m.data.length, m.data.length, m.wb, hex.toString(), copies);
        return s.getBytes(ASCII);
    }

    private static byte[] escpos(Mono m, int copies) {
        ByteArrayOutputStream o = new ByteArrayOutputStream();
        o.write(0x1B);
        o.write(0x40);
        for (int c = 0; c < copies; c++) {
            o.write(0x1D); o.write(0x76); o.write(0x30); o.write(0);
            o.write(m.wb & 0xFF); o.write((m.wb >> 8) & 0xFF);
            o.write(m.h & 0xFF); o.write((m.h >> 8) & 0xFF);
            o.write(m.data, 0, m.data.length);
            o.write(0x1B); o.write(0x64); o.write(3);
        }
        return o.toByteArray();
    }

    private static int clamp(int v, int lo, int hi) {
        return Math.max(lo, Math.min(hi, v));
    }
}
